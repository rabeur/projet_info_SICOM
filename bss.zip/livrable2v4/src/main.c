#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>

#include <global.h>
#include <notify.h>
#include <lex.h>

#include <LEXEM.h>
#include <QUEUE.h>
#include <TEST_FUNCTIONS.h>
#include <LIST.h>
#include <STRUCT.h>
#include <COLLECT.h>
#include <Dico.h>

/*char t_lex[16][20]={"COMMENT","NL","SYMBOLE","DIRECTIVE","VAL_DECIMAL","REGISTRE","COMA","STRING","VAL_HEXA","ERROR","FT","GUIL","PARENTO","PARENTC","DOT","EMPTY"};*/

int man()
{
  char* path=strdup("tests/miam_sujet.s");
  QUEUE q=create_lexem_queue(path);
  visualize_lexem_queue(q);
}

int main()
{  /*Creation de la file de lexem à partir d'un fichier*/
  char* path=strdup("tests/miam_sujet.s");


  int i;/*permetra de connaitre le numero du lexem*/
  int n=0;
  QUEUE q=create_lexem_queue(path);
/*---------------------------------------------------*/
char* path2=strdup("tests/DICO_INSTRUCTION.txt");


  int NbDefInstructions = 0; int k=0;
  inst_def_t* tab = lect_dico_int("tests/DICO_INSTRUCTION.txt",&NbDefInstructions);

  QUEUE collec_instruct=create_QUEUE();QUEUE collec_data=create_QUEUE();
  QUEUE collec_bss=create_QUEUE();QUEUE collec_symb=create_QUEUE(); /*choisir liste ou table de symbol*/
  QUEUE table_symb=create_QUEUE();
  int shift_inst=0;  int shift_data=0;

  LIST p=(LIST)(q.first); /*liste_lexem;*/

  for (;p->next!=NULL;p=p->next){
    LEXEM* p_lex=((LEXEM*)(p->pdata));
    /*printf("ligne : %d | num : %d | content: %s \n",p_lex->lign,p_lex->num,p_lex->content);*/
    lextype type=p_lex->type;
    switch(type) { /*copier le switch apres le for pour le dernier lexem de la liste*/
        case DIRECTIVE :
              if(strcmp(p_lex->content,".bss")==0){
                    p=p->next;
                    p_lex=((LEXEM*)(p->pdata));
                    if(p_lex->type==FT){
                          p=p->next;
                          p_lex=((LEXEM*)(p->pdata));
                          while (strcmp(p_lex->content,".text")!=0 && strcmp(p_lex->content,".data")!=0){
                            is_dot_space_n(&p,&collec_bss);
                            p=p->next;
                            p_lex=((LEXEM*)(p->pdata));
                          }
                    }
                    else if(p_lex->type==STRING){
                          if(p->next==NULL){break;}
                          if(strcmp(((LEXEM*)(p->next->pdata))->content,":")==0){
                                add_symb(&collec_symb, p_lex->content, p_lex->lign);
                          }
                    }
                    else{
                      printf("Erreur: élément non accepté dans la section bss - ligne %d\n", p_lex->lign);
                    }
              }
           break;

        case STRING :
            i=0;
            if (recherche_instruction(p_lex->content,tab,NbDefInstructions,&i) == 1){
                  instruction* p_inst =  add_inst( p_lex->content, i-1, p_lex->lign, &shift_inst, tab);
                  queue_pull_on(&collec_instruct, p_inst);
            }
            else{
                  if(p->next==NULL){break;}
                  if(strcmp(((LEXEM*)(p->next->pdata))->content,":")==0){
                        add_symb(&collec_symb, p_lex->content, p_lex->lign);
                  }
           }

        /*case VAL_HEXA :
            printf("C'est une val hexa\n" );
            break;
        case ERROR :
            printf("C'est une erreur\n" );
            break;
        case FT :
           printf("C'est un, Fin de Texte\n" );
           break;
        case GUIL :
           printf("C'est une guillemet\n" );
           break;
        case PARENTO :
           printf("C'est une parenthese ouvrante\n" );
          break;
        case PARENTC :
           printf("C'est une parenthese fermante\n" );
          break;
        case DOT :
           printf("C'est un point\n" );
          break;
        case EMPTY :
           printf("C'est vide\n" );
          break;*/
        default :
           /*printf("C'est pas dans l'enum lextype\n" );
           /*collec_symb=add_symb(collec_symb, p_lex->content, p_lex->lign,2);/*faut creer une fct qui determine le dacallage du lexem! (a la place du 2)*/
           break;
  }
k++;
  }
/*visualize_lexem_queue(q);*/
/*visualize_Inst_queue(collec_instruct);*/
/*visualize_symb_queue(collec_symb);*/
visualize_bss_elem_queue(collec_bss);
printf("end\n");
/*free_queue(q);*/
/*
  visualize_lexem_queue(q);
*/
 return EXIT_SUCCESS;
}
