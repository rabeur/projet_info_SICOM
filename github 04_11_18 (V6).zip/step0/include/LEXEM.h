#ifndef _LEXEM
#define _LEXEM

typedef enum {
    COMMENT, /*0*/
    NL, /*1*/
    SYMBOLE, /*2*/
    DIRECTIVE, /*3*/
    VAL_DECIMAL,/*4*/
    REGISTRE,/*5*/
    COMA,/*6*/
    STRING,/*7*/
    VAL_HEXA,/*8*/
    ERROR,/*9*/
    FT,/*10*/
    GUIL,/*11*/
    PARENTO,/*12*/
    PARENTC,/*13*/
    DOT,/*14*/
    EMPTY/*15*/
  } lextype;

typedef struct lex {
  lextype type;
  char content[512];
  int lign;
  char error[512];
} LEXEM;

LEXEM* new_lexem(char* content, lextype type, int lign);

#endif
