#ifndef _STRUCT
#define _STRUCT


typedef enum {
    BYTE,
    WORD,
    ASCIIZ,
    LABEL,
    SPACE
  } OPTYPE;

typedef struct{
    OPTYPE type;
    union{
      char byte;
      int word;
      char* asciiz;
      char* label;
      unsigned int space;
    } VAL;
} DATA_OP;

/*-----Maillon collection instruction------*/
typedef enum {
    ADD
  } INST_TYPE;

typedef struct{
  INST_TYPE inst_type;
  int nb_op;
  int lign;
  int shift;
  DATA_OP Op1;
  DATA_OP Op2;
  DATA_OP Op3;
}instruction;

/*-------Maillon collec data et bss-----------*/
typedef enum {
    word,
    byte,
    space
  } DATA_TYPE;

typedef struct{
  DATA_TYPE data_type;
  int nb_op;
  int lign;
  int shift;
  DATA_OP op;
}data;

/*Table symbole (table de hachage ou liste) contient les etiquette et le decallage par rapport au debut de section*/
typedef struct{
  char* content;
  int lign;
  int shift;
}SYMB;

#endif
