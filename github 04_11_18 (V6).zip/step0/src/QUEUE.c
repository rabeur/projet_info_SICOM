#include<stdio.h>
#include<stdlib.h>
#include "QUEUE.h"
#include "LIST.h"
#include "LEXEM.h"
/*Crée une file vide */
/*QUEUE create_queue(void){
  QUEUE q;
  q-
  return q;
}*/
/* ajoute un élément en fin de file*/
QUEUE create_QUEUE(void){
  QUEUE q;
  q.first = NULL;
  return q;
}

void queue_pull_on(QUEUE *q, void* pdata)
{
  MAILLON *queue=calloc(1,sizeof(*queue));
      if (q == NULL || queue == NULL)
      {
          exit(EXIT_FAILURE);
      }
  queue->pdata=pdata;
  queue->next = NULL;
  if (q->first != NULL) /* La file n'est pas vide */
    {
        /* On se positionne à la fin de la file */
        MAILLON *elementActuel = q->first;
        while (elementActuel->next != NULL)
        {
            elementActuel = elementActuel->next;
        }
        elementActuel->next = queue;
    }
    else /* La file est vide, notre élément est le premier */
    {
        q->first = queue;
    }
/*  // if (q==NULL)
  // {
  //   queue->next=NULL;
  //   return queue;
  // }
  //queue->next=q->next;
  q->next=queue;
  return queue;*/
}



/* permet de visualiser la file */
void visualize_int_queue(QUEUE *q){
  if (q==NULL)
    printf("[]\n");
  else{
    printf("[");
    while((((MAILLON*)q->first)->next) != NULL)
    {
      void* Data = defiler (q);
      printf("content : %s, ligne : %i, type %d\n", ((LEXEM*)Data )-> content ,((LEXEM*)Data) -> lign, ((LEXEM*)Data) -> type);
    }
    printf("]\n");
    /*QUEUE queue=q->next;
    for(;queue!=q;queue=queue->next){
      if(queue==NULL){
        puts("Error: input isn't a queue.]");
        return;
      }
      printf("%d",*((int*)queue->pdata));
      if (queue!=q)
        printf(", ");
      }
    printf("%d]",*((int*)queue->pdata));*/
  }
}

/*Permet à la fct visualize_lexem_queue d'affichier le nom des enum dans la console*/
char tab_enum[16][20]={"COMMENT","NL","SYMBOLE","DIRECTIVE","VAL_DECIMAL","REGISTRE","COMA","STRING","VAL_HEXA","ERROR","FT","GUIL","PARENTO","PARENTC","DOT","EMPTY"};
void visualize_lexem_queue(QUEUE q){
  int i=1;
  while (q.first != NULL)
 {
   MAILLON *elementDefile = q.first;
   type_lexem(((LEXEM*)(elementDefile->pdata)));
   void* Data = defiler (&q);
   printf("Lexem %d: [content : %s | type: %s | lign %i]\n",i, ((LEXEM*)Data )-> content , tab_enum[((LEXEM*)Data) -> type], ((LEXEM*)Data) -> lign);
   q.first= elementDefile->next;
   i++;
 }
}

void* defiler(QUEUE *q)
{
    if (q == NULL)
    {exit(EXIT_FAILURE);}
    void* Data;
    /* On vérifie s'il y a quelque chose à défiler */
    if (q->first != NULL)
    {
        MAILLON *elementDefile = q->first;
        Data = elementDefile->pdata;
        q->first= elementDefile->next;
        free(elementDefile);
    }
    return Data;
}

void free_queue(QUEUE *q)
{
  if (q == NULL)
  {
      exit(EXIT_FAILURE);
  }
  /* On vérifie s'il y a quelque chose à défiler */
  if (q->first != NULL)
  {
      MAILLON *elementDefile = q->first;
      q->first= elementDefile->next;
      free(elementDefile);
  }
}
