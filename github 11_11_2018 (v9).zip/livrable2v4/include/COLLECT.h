#ifndef _COLLECT
#define _COLLECT

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>

#include <global.h>
#include <notify.h>
#include <lex.h>

#include <LEXEM.h>
#include <QUEUE.h>
#include <TEST_FUNCTIONS.h>
#include <LIST.h>
#include <STRUCT.h>
#include <Dico.h>

instruction* add_inst(char * content,int i , int lign,int* shift_inst, inst_def_t* tab);
void add_symb(QUEUE* p_q, char* content, int lign);
int recherche_instruction(char* content,inst_def_t* tab,int NbDefInstructions, int* i);
void modif_Op_inst(instruction* p_inst);

#endif
