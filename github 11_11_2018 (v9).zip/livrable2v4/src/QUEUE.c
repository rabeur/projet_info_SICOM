#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>

#include <global.h>
#include <notify.h>
#include <lex.h>

#include <LEXEM.h>
#include <TEST_FUNCTIONS.h>
#include <LIST.h>
#include <STRUCT.h>
#include <COLLECT.h>
#include <Dico.h>
#include <QUEUE.h>
/*Crée une file vide */
/*QUEUE create_queue(void){
  QUEUE q;
  q-
  return q;
}*/
/* ajoute un élément en fin de file*/
QUEUE create_QUEUE(void){
  QUEUE q;
  q.first = NULL;
  return q;
}

void queue_pull_on(QUEUE *q, void* pdata)
{
  MAILLON *queue=calloc(1,sizeof(*queue));
      if (q == NULL || queue == NULL)
      {
        printf("error queue_pull_on\n");
          exit(EXIT_FAILURE);
      }
  queue->pdata=pdata;
  queue->next = NULL;
/*  printf("step 0.1 ");*/
  if (q->first != NULL) /* La file n'est pas vide */
    {
        /* On se positionne à la fin de la file */
        MAILLON *elementActuel = q->first;
      /*  printf("step 0.2 ");*/
        while (elementActuel->next != NULL)
        {
            elementActuel = elementActuel->next;
        }
        elementActuel->next = queue;
        /*printf("step 0.3\n");*/
    }
    else /* La file est vide, notre élément est le premier */
    {
        q->first = queue;
        /*printf("step 0.0.2\n");*/
    }
/*  // if (q==NULL)
  // {
  //   queue->next=NULL;
  //   return queue;
  // }
  //queue->next=q->next;
  q->next=queue;
  return queue;*/
}



/* permet de visualiser la file */
void visualize_int_queue(QUEUE *q){
  if (q==NULL)
    printf("[]\n");
  else{
    printf("[");
    while((((MAILLON*)q->first)->next) != NULL)
    {
      void* Data = defiler (q);
      printf("content : %s, ligne : %i, type %d\n", ((LEXEM*)Data )-> content ,((LEXEM*)Data) -> lign, ((LEXEM*)Data) -> type);
    }
    printf("]\n");
    /*QUEUE queue=q->next;
    for(;queue!=q;queue=queue->next){
      if(queue==NULL){
        puts("Error: input isn't a queue.]");
        return;
      }
      printf("%d",*((int*)queue->pdata));
      if (queue!=q)
        printf(", ");
      }
    printf("%d]",*((int*)queue->pdata));*/
  }
}

/*Permet à la fct visualize_lexem_queue d'affichier le nom des enum dans la console*/
char tab_enum[16][20]={"COMMENT","NL","SYMBOLE","DIRECTIVE","VAL_DECIMAL","REGISTRE","COMA","STRING","VAL_HEXA","ERROR","FT","GUIL","PARENTO","PARENTC","DOT","EMPTY"};
void visualize_lexem_queue(QUEUE q){
  int i=1;
  while (q.first != NULL)
 {
   MAILLON *elementDefile = q.first;
   /*type_lexem(((LEXEM*)(elementDefile->pdata)));*/
   void* Data = defiler (&q);
   printf("Lexem %d: [content : %s | type: %s | lign %i]\n",i, ((LEXEM*)Data )-> content , tab_enum[((LEXEM*)Data) -> type], ((LEXEM*)Data) -> lign);
   q.first= elementDefile->next;
   i++;
 }
}
/*
void visualize_Inst_queue(QUEUE q){
  int i=1;*/
  /*printf("step 2\n");*/
/*  while (q.first != NULL && i<100)
 {

   MAILLON *elementDefile = q.first;*/
   /*type_lexem(((LEXEM*)(elementDefile->pdata)));*/
   /*printf("step 3\n");*/
/*   void* Data = defiler (&q);*/
   /*printf("step 6\n");*/
/*   printf("instruction %d: [nom = %s | type = %c | nb_op = %d | lign = %i | shift = %d ",i, ((instruction*)Data )-> nom , ((instruction*)Data) -> inst_type,((instruction*)Data) -> nb_op, ((instruction*)Data) -> lign,((instruction*)Data) -> shift);
   printf("|| Op1.type = %d || Op2.type = %d || Op3.type = %d ||]\n", ((instruction*)Data) -> Op1.type, ((instruction*)Data) -> Op2.type, ((instruction*)Data) -> Op3.type);
   q.first= elementDefile->next;
   i++;
 }
}*/
/*  Meme fct qu'au dessus mais permet d'afficher correctement les enum dans la console*/
char tab_enum_optype[6][15]={"REG","BASE_OFFSET","NOMBRE","SYMBOL","RIEN","PAS_INIT"};
void visualize_Inst_queue(QUEUE q){
  int i=1;

  while (q.first != NULL && i<100)
 { MAILLON *elementDefile = q.first;
   void* Data = defiler (&q);
   printf("instruction %d: [nom = %s | type = %c | nb_op = %d | lign = %i | shift = %d ",i, ((instruction*)Data )-> nom , ((instruction*)Data) -> inst_type,((instruction*)Data) -> nb_op, ((instruction*)Data) -> lign,((instruction*)Data) -> shift);
   printf("|| Op1.type = %s || Op2.type = %s || Op3.type = %s ||]\n", tab_enum_optype[((instruction*)Data) -> Op1.type], tab_enum_optype[((instruction*)Data) -> Op2.type], tab_enum_optype[((instruction*)Data) -> Op3.type]);
   q.first= elementDefile->next;
   i++;
 }
}


void visualize_symb_queue(QUEUE q){
  int i=1;

  while (q.first != NULL && i<100)
 { MAILLON *elementDefile = q.first;
   SYMB* psymb = ((SYMB*)defiler (&q));
   printf("Symbole %d: [content = %s | lign = %d | shift = %d ]\n",i, psymb->content, psymb->lign,psymb->shift);
  q.first= elementDefile->next;
   i++;
 }
}

void* defiler(QUEUE *q)
{
    /*printf("step 4\n");*/
    if (q == NULL)
    {printf("Q est NULL"); exit(EXIT_FAILURE);}
    void* Data;
    /*printf("step 5\n");*/
    /* On vérifie s'il y a quelque chose à défiler */
    if (q->first != NULL)
    {
        MAILLON *elementDefile = q->first;
        Data = elementDefile->pdata;
        q->first= elementDefile->next;
        free(elementDefile);
    }
    return Data;
}

void free_queue(QUEUE *q)
{
  if (q == NULL)
  {
      exit(EXIT_FAILURE);
  }
  /* On vérifie s'il y a quelque chose à défiler */
  if (q->first != NULL)
  {
      MAILLON *elementDefile = q->first;
      q->first= elementDefile->next;
      free(elementDefile);
  }
}
