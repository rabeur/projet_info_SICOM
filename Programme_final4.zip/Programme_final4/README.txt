Le programme permet, à partir d'un code asm (.s), de réaliser une analyse lexical puis syntaxique, de générer des 4 collections (instruction, data, bss et symbole) et de les afficher à l'écran. 

- tests : contient les fichiers pour tester le programme ainsi que le dictionnaire d'instructions.
- src : contient le code C.      
- include : contient toutes les définitions de types et prototypes du programme.
- Doxyfile : fichier de configuration du générateur automatique de documentation doxygen
- Makefile : permet de compiler le compiler soit en mode debug (afficher les traces du programme) soit en mode release (produit final)
--- pour compiler le code en mode debug (il créé l'exécutable 'as-mips' qui affiche les traces)
	make debug 
--- pour compiler le code en mode release (il créé l'exécutable 'as-mips' qui n'affiche pas les traces)
	make release 
--- Génération de l'archive 
	make archive


Pour lancer l'executable as-mip, entrer dans l'invite de commande la ligne:  ./as-mips FICHIER.s
FICHIER est le du fichier auquel on applique le programme si celui-ci est à la racine du dossier sinon FICHIER est le chemin permmettant d'accéder au fichier.










