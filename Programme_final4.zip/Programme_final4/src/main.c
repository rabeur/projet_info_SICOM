#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>

#include <global.h>
#include <notify.h>
#include <lex.h>

#include <LEXEM.h>
#include <QUEUE.h>
#include <TEST_FUNCTIONS.h>
#include <LIST.h>
#include <STRUCT.h>
#include <COLLECT.h>
#include <Dico.h>


int main(int agrc, char* argv[])
{  /*Creation de la file de lexem à partir d'un fichier*/
  if(agrc!=2){ERROR_MSG("Fichier passé en paramètre inexistant ou non valide");}
  char* path=strdup(argv[1]);
  int test_pseudo;
  int NbDefInstructions = 0 ;
  inst_def_t* tab = lect_dico_int("tests/DICO_INSTRUCTION.txt",&NbDefInstructions);
  QUEUE q=create_lexem_queue(path);
  /*QUEUE l=q;
  printf("step1\n");
  visualize_lexem_queue(l);*/
  find_and_modif_pseudoinst(q.first,&test_pseudo);
  /*QUEUE l=q;
  printf("step1\n");
  visualize_lexem_queue(l);*/
  normalisation_lignes(q.first);
  if (test_pseudo ==1){
    ERROR_MSG("pseudo intruction mal remplie\n");
    return EXIT_FAILURE;
  }
  /*QUEUE l=q;
  printf("step1\n");
  visualize_lexem_queue(l);*/

/*---------------------------------------------------*/

  /*printf("NbDefInstructions = %d\n",NbDefInstructions);
  for (i=0;i <NbDefInstructions;i++)
  {
    printf("tab[%d] :.nom = %s  .type = %c  .nb_op = %d \n",i,tab[i].nom,tab[i].type,tab[i].nb_op);
  }*/
  QUEUE collec_instruct=create_QUEUE();
  QUEUE collec_data=create_QUEUE();
  QUEUE collec_bss=create_QUEUE();
  QUEUE collec_symb=create_QUEUE(); /*choisir liste ou table de symbol*/
  int shift_txt=0;
  int test_instr;
  int test_bss;
  int test_data;
  MAILLON* p=(MAILLON*)(q.first);/*liste_lexem;*/
  for (;p->next!=NULL;p=p->next){

    LEXEM* p_lex=((LEXEM*)(p->pdata));
    lextype type=p_lex->type;
    switch(type) {
        case DIRECTIVE :
        /*___________BSS PART__________*/

         if(strcmp(p_lex->content,".bss")==0){
               test_bss =collection_bss( p,&collec_bss, &collec_symb);
               if (test_bss == 0){
                    ERROR_MSG("ERROR .BSS élément ligne %d : mal rentrée",((LEXEM*)p->pdata)->lign);
               }
         }
         /*___________DATA PART__________*/
         else if(strcmp(p_lex->content,".data")==0){
               test_data =collection_data( p,&collec_data, &collec_symb);
               if (test_data == 0){
                    ERROR_MSG("ERROR .DATA élément ligne %d : mal rentrée",((LEXEM*)p->pdata)->lign);
               }
         }
         /*___________INSTRUCTION PART__________*/
         else if(strcmp(p_lex->content,".text")==0){
               test_instr =collection_instruction( p,&collec_instruct, &collec_symb, &shift_txt, tab, NbDefInstructions);
               if (test_instr == 1){
                    ERROR_MSG("ERROR .TEXT élément ligne %d : mal rentrée",((LEXEM*)p->pdata)->lign);
               }
         }
         break;

         default :

          break;
         }
       }
visualize_collections(collec_instruct,collec_symb,collec_bss,collec_data);


 return EXIT_SUCCESS;
}
