#ifndef _COLLECT
#define _COLLECT

LIST add_lexem(LIST l, lextype type, char * content , int lign, char* error);
LIST add_symb(LIST l, char* content, int lign, int shift);




#endif
