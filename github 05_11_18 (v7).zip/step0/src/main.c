#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>

#include <global.h>
#include <notify.h>
#include <lex.h>

#include <LEXEM.h>
#include <QUEUE.h>
#include <TEST_FUNCTIONS.h>
#include <LIST.h>
#include <STRUCT.h>
#include <COLLECT.h>
#include <Dico.h>


int main()
{  /*Creation de la file de lexem à partir d'un fichier*/
  char* path=strdup("tests/miam_sujet.s");
/*  strcat(path,"miam_sujet.s*/
  int i;/*permetra de connaitre le numero du lexem*/
  QUEUE q=create_lexem_queue(path);
/*---------------------------------------------------*/
char* path2=strdup("tests/DICO_INSTRUCTION.txt");
/*strcat(path,"DICO_INSTRUCTION.txt");*/
  int NbDefInstructions = 0 ;
  inst_def_t* tab = lect_dico_int("tests/DICO_INSTRUCTION.txt",&NbDefInstructions);
  LIST collec_instruct=create_list();
  LIST collec_data=create_list();
  LIST collec_bss=create_list();
  LIST collec_symb=create_list(); /*choisir liste ou table de symbol*/
  LIST table_symb=create_list();

  /*LIST liste_lexem=create_list();*/

  LIST p=(LIST)(q.first);/*liste_lexem;*/
puts("step1\n");
  for (;p->next!=NULL;p=p->next){

    LEXEM* p_lex=((LEXEM*)(p->pdata));
printf("ligne : %d | num : %d | content: %s ",p_lex->lign,p_lex->num,p_lex->content);
    lextype type=p_lex->type;
    switch(type) { /*copier le switch apres le for pour le dernier lexem de la liste*/
        case COMMENT:
           printf("C'est un com!\n" );
           collec_symb=add_symb(collec_symb, p_lex->content, p_lex->lign,p_lex->num);/*faut creer une fct qui determine le dacallage du lexem! (a la place du 2)*/
           printf("     Symb: %s\n",((SYMB*)collec_symb->pdata)->content);
           break;
        case NL :
          printf("C'est une nouvelle ligne!\n" );
           break;
        case SYMBOLE :
           printf("c'est un symbole\n" );
           break;
        case DIRECTIVE :
           printf("c'est une directive\n" );
           break;
        case VAL_DECIMAL :
           printf("C'est une val decimale\n" );
           break;
        case REGISTRE :
           printf("C'est un registre\n" );
           break;
        case COMA :
           printf("C'est une virgule\n" );
           break;
        case STRING :
            printf("C'est une chaine de caract\n" );
            break;
        case VAL_HEXA :
            printf("C'est une val hexa\n" );
            break;
        case ERROR :
            printf("C'est une erreur\n" );
            break;
        case FT :
           printf("C'est un, Fin de Texte\n" );
           break;
        case GUIL :
           printf("C'est une guillemet\n" );
           break;
        case PARENTO :
           printf("C'est une parenthese ouvrante\n" );
          break;
        case PARENTC :
           printf("C'est une parenthese fermante\n" );
          break;
        case DOT :
           printf("C'est un point\n" );
          break;
        case EMPTY :
           printf("C'est vide\n" );
          break;
        default :
           printf("C'est pas dans l'enum lextype\n" );
           collec_symb=add_symb(collec_symb, p_lex->content, p_lex->lign,2);/*faut creer une fct qui determine le dacallage du lexem! (a la place du 2)*/
     }

  }

/*
  visualize_lexem_queue(q);
*/
 return EXIT_SUCCESS;
}
