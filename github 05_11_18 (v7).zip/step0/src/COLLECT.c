#include <LEXEM.h>
#include <stdio.h>
#include <QUEUE.h>
#include <STRUCT.h>
#include <LIST.h>
#include <string.h>

LIST add_symb(LIST l, char* content, int lign, int shift){
  SYMB* p_symb = calloc(1,sizeof(*p_symb));

  p_symb->content = calloc(strlen(content)+1, sizeof(char));
  strcpy(p_symb->content,content);

  p_symb->lign=lign;

  p_symb->shift=shift;

  LIST ppair = calloc(1,sizeof(*ppair));
  ppair->pdata = p_symb;
  ppair->next = l;

  return ppair;
}
/*
LIST add_lexem(LIST l, lextype type, char* content , int lign, char* error){
  LEXEM* p_lex = calloc(1,sizeof(*p_lex));

  p_lex->type=type;

  p_lex->content = calloc(strlen(content)+1, sizeof(char));
  strcpy(p_lex->content,content);

  p_lex->lign=lign;

  p_lex->error = calloc(strlen(error)+1, sizeof(char));
  strcpy(p_lex->error,"");

  LIST ppair = calloc(1,sizeof(*ppair));
  ppair->pdata = p_lex;
  ppair->next = l;

  return ppair;
}
*/
