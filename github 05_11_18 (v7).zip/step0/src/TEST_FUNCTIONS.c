#include<stdio.h>
#include<stdlib.h>
#include <string.h>
#include <ctype.h>
#include <strings.h>
#include <LEXEM.h>
#include <QUEUE.h>
#include <TEST_FUNCTIONS.h>
#include <LIST.h>

#include <global.h>
#include <notify.h>
#include <lex.h>

void test_commentaire(LEXEM* plex)
{
  plex->type=COMMENT;
}
void test_coma(LEXEM*plex){plex->type=COMA;}
void test_parentc(LEXEM*plex){plex->type=PARENTC;}
void test_parento(LEXEM*plex){plex->type=PARENTO;}
void test_mots(LEXEM*plex){plex->type=STRING;}
void test_NL(LEXEM*plex){plex->type=NL;}
void test_FT(LEXEM*plex){plex->type=FT;}
void test_guil(LEXEM*plex){plex->type=GUIL;}

void test_dot(LEXEM* plex){plex->type=DIRECTIVE;}

void test_registre(LEXEM* plex){
  /*int*   regAvail[64]={"0","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22",
  "23","24","25","26","27","28","29","30","31","zero","at","v0","v1","a0","a1","a2","a3","t0","t1","t2","t3","t4","t5","t6",
  "t7","s0","s1","s2","s3","s4","s5","s6","s7","t8","t9","k0","k1","gp","sp","fp","ra"};*/
  char  length1[10]={'0','1','2','3','4','5','6','7','8','9'};
  char  length21[11]={'1','2','t','3','a','v','s','k','g','f','r'};
  char  length4[4]={'z','e','r','o'};
  /*ne comprend pas les nombre a + de 2 chiffres*/
  int i=0;
  int test;
  char* s=plex->content;
  /*printf("s[i] = %c,  ",s[0]);*/

  while (s[i]!='\0')
  {
    i++;
  }
  /*printf("s[i] = %c,  ",s[i]);*/
  switch(i)
  {
    case 2:

        if (s[1]!='\0' && is_in(s[1],length1,10)) plex->type=5;
        else plex->type=9;
        break;


    case 3:
        if (s[1]!='\0' && is_in(s[1],length21,11))
            {
              if (s[1]!='\0' && is_in(s[1],length21,3))
              {
                if (s[2]!='\0' && is_in(s[2],length1,10)) plex->type=5;
                else plex->type=9;
              }
              else if (s[1]!='\0' && s[1]=='3')
              {
                if (s[2]!='\0' && is_in(s[2],length1,2)) plex->type=5;
                else plex->type=9;
              }
              else if (s[1]!='\0' && s[1]=='s')
              {
                if (s[2]!='\0' && (is_in(s[2],length1,8) || s[2]=='p')) plex->type=5;
                else plex->type=9;
              }
              else if (s[1]!='\0' && s[1]=='a')
              {
                if (s[2]!='\0' && (is_in(s[2],length1,4) || s[2]=='t')) plex->type=5;
                else plex->type=9;
              }
              else if (s[1]!='\0' && (s[1]=='k' || s[1]=='v'))
              {
                if (s[2]!='\0' && is_in(s[2],length1,2)) plex->type=5;
                else plex->type=9;
              }
              else if (s[1]!='\0' && (s[1]=='g' || s[1]=='f' ))
              {
                if (s[2]!='\0' && s[2]=='p') plex->type=5;
                else plex->type=9;
              }
              else if (s[1]!='\0' && (s[1]=='r'))
              {
                if (s[2]!='\0' && s[2]=='a') plex->type=5;
                else plex->type=9;
              }
              else plex->type=9;
            }
        else plex->type=9;
        break;


    case 5:

        for (i=0;i<4;i++)
            {
                if (s[i+1]==length4[i]) test=1;
                else {test = 0; i=4;}
                /*printf("s[%d] = %c,length4[%d] = %c ",i+1,s[i+1],i,length4[i]);
                printf("test = %d\n",test );*/
            }
        if (test == 1) plex->type=5;
        else plex->type=9;
        break;


    default:

        /*printf("etape error2\n");*/
        /*char dest[512]="Register doesn't exist - Lign ";
        /*printf("etape error2.1\n");*/
        /*strcat(dest,(char*)plex->lign);*/ /*pb sur cette fct*/
        /*printf("etape error2.2\n");
        strcpy(plex->error, dest);
        /*printf("etape error2.3\n");*/
        plex->type=9;
        break;

  }


/*  /*printf("s = %d, \n",s,s);
  printf("tab = %d, \n",regAvail[0], regAvail[0]);*/
/*  if (s[1]!='\0' && is_in(s,regAvail,64)){
    /*printf("etape 2\n");
    plex->type=5;
  }*/

  /*else if(s[2]!='\0'){
    /*printf("etape error1\n");
    char dest[512]="Register doesn't exist - Lign ";
  /* strcat(dest,(char)plex->lign); /*pb sur cette fct
   strcpy(plex->error, dest);
   plex->type=9;

 }*/

  /*else if (s[2]!='\0'){
    int i;
    char str[3];str[0]=*s;str[1]=*(s+1);str[2]='\0';
      for(i=0;i<31;i++){
        if (strcmp(str,regAvail[i])==0)
            plex->type=5;
            return;
      }
      char dest[512]="Register doesn't exist - Lign ";
      strcat(dest,(char)plex->lign);
      strcpy(plex->error, dest);
      plex->type=9;
  }*/
/*  else{
    printf("etape error2\n");
    char dest[512]="Register doesn't exist - Lign ";
    /*printf("etape error2.1\n");*/
    /*strcat(dest,(char*)plex->lign);*/ /*pb sur cette fct*/
    /*printf("etape error2.2\n");
    strcpy(plex->error, dest);
    /*printf("etape error2.3\n");
    plex->type=9;
  }*/
}


void test_nombre(LEXEM* plex){
  char digit[10]={'0','1','2','3','4','5','6','7','8','9'};
  char digithexa[16]={'0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f'};

  char* pc=plex->content;
  int testdeci=1;
  int testhexa=1;

  /* Si le s commence par 0x on verifie que ce qui suit est bien un nombre hexa*/
  if (*pc=='0' && *(pc+1)=='x'){
    /*printf("hexa1 \n  ");*/
      pc+=2;
      do{
        testhexa=testhexa && is_in(*pc,digithexa,16);
        pc++;
      /*  printf("hexa2 : %d\n  ",testhexa);*/
      } while (*pc!='\0');
      /*printf("hexa2 : %d\n  ",testhexa);*/
      if (testhexa==1){
        plex->type=8;
      }
      else {
        /*printf("lololo\n");*/
        char dest[512]="Hexadecimal doesn't exist - Lign ";
        /*strcat(dest,(char)plex->lign); */ /*pb sur cette fct*/
        strcpy(plex->error, dest);
        plex->type=9;
      }
  }

  /* On verifie que ce qui suit est bien un nombre decimal*/
  else if (*pc=='-' || *pc=='+'){
      pc++;
      while(*pc==' ') pc++; /*on passe les blancs entre les signes et les chiffres*/
      do{
        testdeci=testdeci && is_in(*pc,digit,10);
        pc++;
      }while (*pc!='\0');
      if (testdeci==1)
        plex->type=4;
      else {
        char dest[512]="Number doesn't exist - Lign ";
        /*strcat(dest,(char)plex->lign);*/ /*pb sur cette fct*/
        strcpy(plex->error, dest);
        plex->type=9;
      }
  }
  else {
    while(*pc==' ') pc++; /*on passe les blancs entre les signes et les chiffres*/
    do{
      testdeci=testdeci && is_in(*pc,digit,10);
      pc++;
    }while (*pc!='\0');
    if (testdeci==1)
      plex->type=4;
    else {
      char dest[512]="Number doesn't exist - Lign ";
      /*strcat(dest,(char)plex->lign);*/ /*pb sur cette fct*/
      strcpy(plex->error, dest);
      plex->type=9;
    }
  }
}

int is_in(char  c,char* tab,int n){  /*test si le caractere c appartient au tableau tab*/
  /*printf("is_in etape1\n");*/
  int i;
  if (n==0) {
    /*printf("is_in error\n");*/
    return 0;}
  for (i=0;i<n;i++){
    if (tab[i]==c) return 1;
    /*printf("is_in etape b%d\t",i);*/
    }
  return 0;
}
/*
LIST fill_list_number(int min, int max){
  if (min>max) return NULL;
  LIST l=create_list();
  char* tab =calloc(max-min+1,sizeof(*tab));
  int i;
  for (i=max;i>=min;i--){
    tab[i-1]=(char)i;
    printf("%c, ", tab[i-1]);
    l=head_insert_list(l,tab+i-1);
    }
}
*/
