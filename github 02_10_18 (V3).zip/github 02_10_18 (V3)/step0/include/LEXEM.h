#ifndef _LEXEM
#define _LEXEM

typedef enum {
    COMMENT,
    NL,
    SYMBOLE,
    DIRECTIVE,
    VAL_DECIMAL,
    REGISTRE,
    COMA,
    STRING,
    VAL_HEXA,
    ERROR,
    FT,
    GUIL,
    PARENTO,
    PARENTC,
    DOT,
    EMPTY
  } lextype;


typedef struct lex {
  lextype type;
  char content[512];
  int lign;
  char error[512];
} LEXEM;

#endif
