#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>

#include <global.h>
#include <notify.h>
#include <lex.h>

#include <LEXEM.h>
#include <QUEUE.h>
#include <TEST_FUNCTIONS.h>
#include <LIST.h>
#include <STRUCT.h>
#include <COLLECT.h>
#include <Dico.h>


int main(int agrc, char* argv[])
{
  if(agrc!=2){ERROR_MSG("Fichier passé en paramètre inexistant ou non valide");}

  /*Creation de la file de lexem à partir d'un fichier*/
  char* path=strdup(argv[1]);
  QUEUE q=create_lexem_queue(path);

  QUEUE collec_instruct=create_QUEUE();
  QUEUE collec_data=create_QUEUE();
  QUEUE collec_bss=create_QUEUE();
  QUEUE collec_symb=create_QUEUE();

  int test_pseudo;
  int i; /*permetra de connaitre le numero du lexem*/
  int NbDefInstructions = 0 ;
  inst_def_t* tab = lect_dico_int("tests/DICO_INSTRUCTION.txt",&NbDefInstructions);

  find_and_modif_pseudoinst(q.first,&test_pseudo);

  normalisation_lignes(q.first);
  if (test_pseudo ==1){
        ERROR_MSG("pseudo intruction mal remplie");
  }

  int shift_txt=0;

  int test_instr;
  int test_bss;
  int test_data;

  int k=0;
  int inst_num=0;
  MAILLON* p=(MAILLON*)(q.first); /*liste_lexem;*/


  for (;p->next!=NULL;p=p->next){

    LEXEM* p_lex=((LEXEM*)(p->pdata));
    lextype type=p_lex->type;

    switch(type) {
        case DIRECTIVE :
        /*___________BSS PART__________*/

         if(strcmp(p_lex->content,".bss")==0){
               test_bss =collection_bss( p,&collec_bss, &collec_symb);
               if (test_bss == 0){
                    ERROR_MSG("ERROR .BSS élément ligne %d : mal rentrée",((LEXEM*)p->pdata)->lign);
               }
         }
         /*___________DATA PART__________*/
         else if(strcmp(p_lex->content,".data")==0){
               test_data =collection_data( p,&collec_data, &collec_symb);
               if (test_data == 0){
                    ERROR_MSG("ERROR .DATA élément ligne %d : mal rentrée",((LEXEM*)p->pdata)->lign);
               }
         }
         break;

        case STRING :

            i=0;
            if (recherche_instruction(p_lex->content,tab,NbDefInstructions,&i) == 1){
              inst_num ++;
              instruction* p_inst =  add_inst( p_lex->content, i-1, p_lex->lign, &shift_txt, tab);
              test_instr = modif_Op_inst(p_inst,p);
              if(test_instr==1){
                    ERROR_MSG("\nInstruction ligne = %d || mal appelée_1\n",p_inst->lign);
              }
              test_instr = extract_Op(p_inst);
              if(test_instr==1){
                    ERROR_MSG("\nInstruction ligne = %d || mal appelée_2\n",p_inst->lign);
              }
              test_instr = test_inst(p_inst,tab); /*ne traite pas des cas des base offset() des pseudo-instruc*/
              if(test_instr==1){
                    ERROR_MSG("\nInstruction ligne = %d || mal appelée_3\n",p_inst->lign);
              }


              queue_pull_on(&collec_instruct, p_inst );
            }
            break;

            default :
            break;
         }
         k++;
       }

  visualize_collections(collec_instruct,collec_symb,collec_bss,collec_data);


 return EXIT_SUCCESS;
}
