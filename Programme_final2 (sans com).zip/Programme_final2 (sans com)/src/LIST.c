#include<stdio.h>
#include<stdlib.h>
#include "LIST.h"

/*Crée une liste vide */
LIST create_list(void){
  LIST l;
  l=NULL;
  return l;
}

/*Ajoute un bloc au début de la liste*/
LIST head_insert_list(LIST l, void* pdata){
  LIST ppair=calloc(1,sizeof(*ppair));
  ppair->next=l;
  ppair->pdata=pdata;
  return ppair;
}
/*supprimme le 1er élément de la liste*/
LIST head_delete_list(LIST l){
	if(!list_empty(l)){
		LIST p=NULL;
		p=l->next;
		free(l);
		return p;
	}
	else return l;
}
/*test si la liste est vide*/
int list_empty(LIST l){
  return (l==NULL);
}
/*vide la liste*/
void free_list(LIST* pl){
  while(!list_empty(*pl)){
	  *pl=head_delete_list(*pl);
    }
    free(*pl);
}
/* permet de visualiser la liste*/
void visualize_int_list(LIST l){
	LIST p=NULL;
	printf("[");
	for (p=l; !list_empty(p); p=p->next){
    printf("%d",*((int*)p->pdata));
		if (!list_empty(p->next))printf(", ");
    }
    puts("]\n");
}
