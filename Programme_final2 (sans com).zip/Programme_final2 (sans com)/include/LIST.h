#ifndef _LIST
#define _LIST
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>

#include <global.h>
#include <notify.h>


typedef struct MAILLON MAILLON;
struct MAILLON
{
  void* pdata;
  struct MAILLON * next;
};

typedef struct pair {
  void* pdata;
  struct pair * next;
}* LIST;

LIST create_list(void);
LIST head_insert_list(LIST l, void* pdata);
LIST head_delete_list(LIST l);
int list_empty(LIST l);
void free_list(LIST* pl);
void visualize_int_list(LIST l);

#endif
