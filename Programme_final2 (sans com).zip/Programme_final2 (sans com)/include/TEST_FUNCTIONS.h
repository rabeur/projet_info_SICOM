#ifndef _TEST_FUNCTIONS
#define _TEST_FUNCTIONS



void test_commentaire(LEXEM*);
void test_coma(LEXEM*);
void test_parentc(LEXEM*);
void test_parento(LEXEM*);
void test_mots(LEXEM*);
void test_NL(LEXEM*);
void test_FT(LEXEM*);
void test_dot(LEXEM*);
void test_registre(LEXEM*);
void test_nombre(LEXEM*);
void test_guil(LEXEM*);
int is_in(char,char*, int n);

#endif
