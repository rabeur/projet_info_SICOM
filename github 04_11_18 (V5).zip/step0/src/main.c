#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>

#include <global.h>
#include <notify.h>
#include <lex.h>

#include <LEXEM.h>
#include <QUEUE.h>
#include <TEST_FUNCTIONS.h>
#include <LIST.h>



int main()
{
  char* path=strdup("tests/");
  strcat(path,"miam_sujet.s");
  QUEUE q=create_lexem_queue(path);

  visualize_lexem_queue(q);

 return EXIT_SUCCESS;
}
