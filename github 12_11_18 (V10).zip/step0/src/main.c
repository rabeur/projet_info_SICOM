#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>

#include <global.h>
#include <notify.h>
#include <lex.h>

#include <LEXEM.h>
#include <QUEUE.h>
#include <TEST_FUNCTIONS.h>
#include <LIST.h>
#include <STRUCT.h>
#include <COLLECT.h>
#include <Dico.h>


int main()
{  /*Creation de la file de lexem à partir d'un fichier*/
  char* path=strdup("tests/miam_sujet.s");
/*  strcat(path,"miam_sujet.s*/
  int i;/*permetra de connaitre le numero du lexem*/
  QUEUE q=create_lexem_queue(path);
  QUEUE l=q;
  QUEUE V;
  printf("step1\n");
  /*visualize_lexem_queue(l);*/
  printf("\n|| fin INI || \n\n");
/*---------------------------------------------------*/
char* path2=strdup("tests/DICO_INSTRUCTION.txt");
/*strcat(path,"DICO_INSTRUCTION.txt");*/
  int NbDefInstructions = 0 ;
  inst_def_t* tab = lect_dico_int("tests/DICO_INSTRUCTION.txt",&NbDefInstructions);
  /*printf("NbDefInstructions = %d\n",NbDefInstructions);
  for (i=0;i <NbDefInstructions;i++)
  {
    printf("tab[%d] :.nom = %s  .type = %c  .nb_op = %d \n",i,tab[i].nom,tab[i].type,tab[i].nb_op);
  }*/
  QUEUE collec_instruct=create_QUEUE();
  QUEUE collec_data=create_QUEUE();
  QUEUE collec_bss=create_QUEUE();
  QUEUE collec_symb=create_QUEUE(); /*choisir liste ou table de symbol*/
  QUEUE table_symb=create_QUEUE();

  int shift_txt=0;
  int shift_data=0;
  int shift_bss=0;

  /*LIST liste_lexem=create_list();*/
  int k=0;
  LIST p=(LIST)(q.first);/*liste_lexem;*/
/*puts("step1\n");*/
  for (;p->next!=NULL;p=p->next){

    LEXEM* p_lex=((LEXEM*)(p->pdata));
    /*printf("ligne : %d | num : %d | content: %s \n",p_lex->lign,p_lex->num,p_lex->content);*/
    lextype type=p_lex->type;
    switch(type) { /*copier le switch apres le for pour le dernier lexem de la liste*/
      /*  case COMMENT:
           printf("C'est un com!\n" );
           /*collec_symb=add_symb(collec_symb, p_lex->content, p_lex->lign,p_lex->num);/*faut creer une fct qui determine le dacallage du lexem! (a la place du 2)*/
           /*printf("     Symb: %s\n",((SYMB*)collec_symb->pdata)->content);*/
        /*   break;
        case NL :
          printf("C'est une nouvelle ligne!\n" );
           break;
        case SYMBOLE :
           printf("c'est un symbole\n" );
           break;
        case DIRECTIVE :
           printf("c'est une directive\n" );
           break;
        case VAL_DECIMAL :
           printf("C'est une val decimale\n" );
           break;
        case REGISTRE :
           printf("C'est un registre\n" );
           break;
        case COMA :
           printf("C'est une virgule\n" );
           break;*/
        case STRING :
            i=0;
            /*printf("C'est une chaine de caract\n" );*/
            if (recherche_instruction(p_lex->content,tab,NbDefInstructions,&i) == 1){
              printf("c'est une instruction\n");

              instruction* p_inst =  add_inst( p_lex->content, i-1, p_lex->lign, &shift_txt, tab);
              printf("Etape d'analyse 1\n");
              modif_Op_inst(p_inst,p);
              printf("Etape d'analyse 2\n");
              queue_pull_on(&collec_instruct, p_inst );
              /* V =collec_instruct;*/
              /*visualize_Inst_queue(collec_instruct);*/
              /*free_queue(&V);*/
              /*printf("collec_instruct = %s\n",((instruction*)((QUEUE*)collec_instruct.first)->pdata)->nom);*/
              printf("fin de l'analyse\n\n\n");

            }

        /*case VAL_HEXA :
            printf("C'est une val hexa\n" );
            break;
        case ERROR :
            printf("C'est une erreur\n" );
            break;
        case FT :
           printf("C'est un, Fin de Texte\n" );
           break;
        case GUIL :
           printf("C'est une guillemet\n" );
           break;
        case PARENTO :
           printf("C'est une parenthese ouvrante\n" );
          break;
        case PARENTC :
           printf("C'est une parenthese fermante\n" );
          break;
        case DOT :
           printf("C'est un point\n" );
          break;
        case EMPTY :
           printf("C'est vide\n" );
          break;*/
        default :
           /*printf("C'est pas dans l'enum lextype\n" );
           /*collec_symb=add_symb(collec_symb, p_lex->content, p_lex->lign,2);/*faut creer une fct qui determine le dacallage du lexem! (a la place du 2)*/
           break;
  }
k++;
  }
/*QUEUE l=collec_instruct;
printf("step1\n");
visualize_Inst_queue(l);*/
/*free_queue(q);*/
/*
  visualize_lexem_queue(q);
*/
 return EXIT_SUCCESS;
}
