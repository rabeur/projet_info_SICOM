#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>

#include <global.h>
#include <notify.h>
#include <lex.h>

#include <LEXEM.h>
#include <QUEUE.h>
#include <TEST_FUNCTIONS.h>
#include <LIST.h>
#include <STRUCT.h>
#include <COLLECT.h>
#include <Dico.h>

/*QUEUE add_symb(QUEUE l, char* content, int lign, int shift){
  SYMB* p_symb = calloc(1,sizeof(*p_symb));

  p_symb->content = calloc(strlen(content)+1, sizeof(char));
  strcpy(p_symb->content,content);

  p_symb->lign=lign;

  p_symb->shift=shift;

  QUEUE ppair = calloc(1,sizeof(*ppair));
  ppair->pdata = p_symb;
  ppair->next = l;

  return ppair;
}*/

int recherche_instruction(char* content,inst_def_t* tab,int NbDefInstructions,int* i)
{
  int j =0; int a=0;
  do {
    if (!strcmp(content, tab[j].nom)) {a=1; /*printf("\na = 1\n");*/}
    j++;
  } while(j<NbDefInstructions && a==0);
  /*printf("\nContent = %s , a = %d, i = %d\n",content,a,j  );*/
  *i=j;
  return a;
}


instruction* add_inst(char* content, int i , int lign, int* shift_inst, inst_def_t* tab){
  instruction* p_inst = calloc(1,sizeof(instruction));

  strcpy(p_inst->nom,(tab[i].nom));

  p_inst->inst_type=tab[i].type;

  p_inst->nb_op = tab[i].nb_op;

  p_inst->lign=lign;

  *shift_inst+=4;
  p_inst->shift=*shift_inst;

  /* On remarque avec ce printf que la structure p_inst est bien remplie comme désiré*/
  /*printf("|| nom = %s || type = %c || nb_op = %d || lign = %d || shift = %d || Op1.type = %d || Op2.type = %d || Op3.type = %d ||\n",p_inst->nom, p_inst->inst_type, p_inst->nb_op, p_inst->lign, p_inst->shift,(int*)p_inst->Op1.type,(int*)p_inst->Op2.type,(int*)p_inst->Op3.type);*/

  return p_inst;
}

modif_Op_inst(instruction* p_inst,LIST p){

  switch (p_inst->nb_op) {
    case 0:
    p_inst->Op1.type=RIEN;
    p_inst->Op2.type=RIEN;
    p_inst->Op3.type=RIEN;
    break;

    case 1:
    printf("||  1.1 ||\n");
    recherche_Op_c1(p,p_inst);
    printf("||  1.2  ||\n");
    p_inst->Op2.type=RIEN;
    p_inst->Op3.type=RIEN;
    break;

    case 2:
    printf("||  2.1  ||\n");
    recherche_Op_c2(p,p_inst);
    printf("||  2.2  ||\n");
    p_inst->Op3.type=RIEN;
    break;

    case 3:
    printf("||  3.1  ||\n");
    recherche_Op_c3(p,p_inst);
    printf("||  3.2  ||\n");
    break;

    default:
    printf("||  ERROR nb_op  ||\n");
    break;}

}

recherche_Op_c1(LIST p,instruction* p_inst){

/* INIT */

  QUEUE q1=create_QUEUE();
  /*LIST L = create_list();
  L =head_insert_list(L, &q1);*/
  int k=0; /* compte le nb d'opérande dans la ligne */
  int i = 0;
  p=p->next;
  LEXEM* p_lex=((LEXEM*)(p->pdata));
  printf("\t\t\tligne = %d\n",p_lex->lign);
  int lign =p_lex->lign;
  int T=0;
  if (p_lex->type!=10) {
    T=1;
  }
  else{
    printf("\\ \\ instruction sans opérande //\n");
  }

  /* debut boucle */
  while (T!=0){

    /*printf("\\ \\ k=%d //\n",k);*/
    k++;
    /*p_lex=((LEXEM*)(p->pdata));*/
    i=0;
  /*  printf("p_lex->type = %d\n",p_lex->type);*/
    switch (k){
      case 1:
      /*UEUE q1=create_QUEUE();*/
      while(T!=0 && lign==lign)
      {

          /*printf("\\ \\ i=%d //\n",i);*/
          queue_pull_on(&q1,p_lex);
          /*printf("lexem bien ajouté à la file\n");*/
          p=p->next;
          p_lex=((LEXEM*)(p->pdata));
          i++;
          T=1;
          /*printf("p_lex->type = %d\n",p_lex->type);*/
          if (p_lex->type==10) T=0;

          /*printf("\\ \\ T=%d //\n",T);*/
      }
      p_inst->Op1.VAL_INST = &q1;
      /*QUEUE* q0 = p_inst->Op1.VAL_INST;
      visualize_lexem_queue(*q0);*/
      break;

      default:
      printf("\nERROR too much argument for this instruction\n");
      return EXIT_FAILURE;
      break;

      }
      printf("\t\t\topérande %d remplie\n",k);

  }
  /* fin boucle integration des sorties */
  /*p_inst->Op1.VAL =&L[0];*/
  /*free_queue(&q1);*/
}

recherche_Op_c2(LIST p,instruction* p_inst){

/* INIT */
  /*printf("\n\\ \\ 1 //\n");*/
  QUEUE q1=create_QUEUE();
  QUEUE q2=create_QUEUE();
  /*QUEUE L = create_QUEUE();
  queue_pull_on(&L, &q1);
  queue_pull_on(&L, &q2);*/
/*  printf("\n\\ \\ 1.1 //\n");*/
  int k=0; /* compte le nb d'opérande dans la ligne */
  int i = 0;
  p=p->next;
  /*printf("\n\\ \\ 1.2 //\n");*/

  LEXEM* p_lex=((LEXEM*)(p->pdata));
  printf("\t\t\tligne = %d\n",p_lex->lign);
  int lign =p_lex->lign;
  int T=0;
  if (p_lex->type!=10) {
    T=1;
  }
  else{
    printf("\\ \\ instruction sans opérande //\n");
  }

  /*printf("\\ \\ T=%d //\n",T);*/
/*  printf("\n\\ \\ 2 //\n");*/
  /* debut boucle */
  while (T!=0){

    /*printf("\\ \\ k=%d //\n",k);*/
    k++;
    /*p_lex=((LEXEM*)(p->pdata));*/
    i=0;
    /*printf("p_lex->type = %d\n",p_lex->type);*/
    switch (k){
      case 1:
      /*UEUE q1=create_QUEUE();*/
      while(T!=0 && lign==lign)
      {

          /*printf("\\ \\ i=%d //\n",i);*/
          queue_pull_on(&q1,p_lex);
          /*printf("lexem bien ajouté à la file\n");*/
          p=p->next;
          p_lex=((LEXEM*)(p->pdata));
          i++;
          T=1;
          /*printf("p_lex->type = %d\n",p_lex->type);*/
          if (p_lex->type==6) T=0;

          /*printf("\\ \\ T=%d //\n",T);*/
      }
      p_inst->Op1.VAL_INST = &q1;
      p=p->next;
      p_lex=((LEXEM*)(p->pdata));
      if (p_lex->type!=10) T=1;
      /*QUEUE* q0 = p_inst->Op1.VAL_INST;
      visualize_lexem_queue(*q0);*/
      break;

      case 2:
      /*QUEUE q2=create_QUEUE();*/
      while(T!=0 && lign==lign)
      {

          /*printf("\\ \\ i=%d //\n",i);*/
          queue_pull_on(&q2,p_lex);
          /*printf("lexem bien ajouté à la file\n");*/
          p=p->next;
          p_lex=((LEXEM*)(p->pdata));
          i++;
          T=1;
          /*printf("p_lex->type = %d\n",p_lex->type);*/
          if (p_lex->type==10 || p_lex->type==6) T=0;

          /*printf("\n\\ \\ T=%d //\n",T);*/
      }
      p_inst->Op2.VAL_INST = &q2;
      /*QUEUE* q00 = p_inst->Op2.VAL_INST;
      visualize_lexem_queue(*q00);*/
      break;

      default:
      printf("ERROR too much argument for this instruction\n");
      return EXIT_FAILURE;
      break;

      }
      printf("\t\t\topérande %d remplie\n",k);


    /*else {
      printf("\nERROR too much argument for this instruction\n");
      return EXIT_FAILURE;
    }*/

  }
  /*free_queue(&q1);
  free_queue(&q2);*/
  /* fin boucle integration des sorties */
/*printf("\n\\ \\ 3 //\n");*/
  /*p_inst->Op1.VAL =((MAILLON*)&L.first)->pdata;*/
  /*p_inst->Op2.VAL =&L[1];*/
  /*printf("\n\\ \\ 4 //\n");*/
}

recherche_Op_c3(LIST p,instruction* p_inst){

/* INIT */

  QUEUE q1=create_QUEUE();
  QUEUE q2=create_QUEUE();
  QUEUE q3=create_QUEUE();
  /*LIST L = create_list();
  L =head_insert_list(L, &q3);
  L =head_insert_list(L, &q2);
  L =head_insert_list(L, &q1);*/
  int k=0; /* compte le nb d'opérande dans la ligne */
  int i = 0;
  p=p->next;
  LEXEM* p_lex=((LEXEM*)(p->pdata));
  printf("\t\t\tligne = %d\n",p_lex->lign);
  int lign =p_lex->lign;
  int T=0;
  if (p_lex->type!=10) {
    T=1;
  }
  else{
    printf("\\ \\ instruction sans opérande //\n");
  }

  /*printf("\\ \\ T=%d //\n",T);*/
  /* debut boucle */
  while (T!=0){

    /*printf("\\ \\ k=%d //\n",k);*/
    k++;
    /*p_lex=((LEXEM*)(p->pdata));*/
    i=0;
    /*printf("p_lex->type = %d\n",p_lex->type);*/
    switch (k){
      case 1:
      /*UEUE q1=create_QUEUE();*/
      while(T!=0 && lign==lign)
      {

          /*printf("\\ \\ i=%d //\n",i);*/
          queue_pull_on(&q1,p_lex);
          /*printf("lexem bien ajouté à la file\n");*/
          p=p->next;
          p_lex=((LEXEM*)(p->pdata));
          i++;
          T=1;
          /*printf("p_lex->type = %d\n",p_lex->type);*/
          if (p_lex->type==6) T=0;

          /*printf("\\ \\ T=%d //\n",T);*/
      }
      p_inst->Op1.VAL_INST = &q1;
      p=p->next;
      p_lex=((LEXEM*)(p->pdata));
      if (p_lex->type!=10) T=1;
      /*QUEUE* q0 = p_inst->Op1.VAL_INST;
      visualize_lexem_queue(*q0);*/
      break;

      case 2:
      /*QUEUE q2=create_QUEUE();*/
      while(T!=0 && lign==lign)
      {

          /*printf("\\ \\ i=%d //\n",i);*/
          queue_pull_on(&q2,p_lex);
          /*printf("lexem bien ajouté à la file\n");*/
          p=p->next;
          p_lex=((LEXEM*)(p->pdata));
          i++;
          T=1;
          /*printf("p_lex->type = %d\n",p_lex->type);*/
          if (p_lex->type==6) T=0;

        /*printf("\\ \\ T=%d //\n",T);*/
      }
      p_inst->Op2.VAL_INST = &q2;
      p=p->next;
      p_lex=((LEXEM*)(p->pdata));
      if (p_lex->type!=10) T=1;
      /*QUEUE* q00 = p_inst->Op2.VAL_INST;
      visualize_lexem_queue(*q00);*/
      break;

      case 3:
      while(T!=0 && lign==lign)
      {

          /*printf("\\ \\ i=%d //\n",i);*/
          queue_pull_on(&q3,p_lex);
          /*printf("lexem bien ajouté à la file\n");*/
          p=p->next;
          p_lex=((LEXEM*)(p->pdata));
          i++;
          T=1;
          /*printf("lex->type = %d\n",p_lex->type);*/
          if (p_lex->type==10 ) T=0;

          /*printf("\\ \\ T=%d //\n",T);*/
      }
      p_inst->Op3.VAL_INST = &q3;
      /*QUEUE* q000 = p_inst->Op3.VAL_INST;
      visualize_lexem_queue(*q000);*/
      break;

      default:
      printf("ERROR too much argument for this instruction\n");
      return EXIT_FAILURE;
      break;

      }
      printf("\t\t\topérande %d remplie\n",k);

  /* fin boucle integration des sorties */
  /*free_queue(&q1);
  free_queue(&q2);
  free_queue(&q3);*/
  /*p_inst->Op1.VAL =&L[0];
  p_inst->Op2.VAL =&L[1];
  p_inst->Op3.VAL =&L[2];*/
}
}
