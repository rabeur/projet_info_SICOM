#ifndef _QUEUE
#define _QUEUE
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>

#include <global.h>
#include <notify.h>
#include <lex.h>


#include <LIST.h>


typedef struct QUEUE QUEUE;
struct QUEUE
{
  MAILLON *first;
};

QUEUE create_QUEUE(void);
void queue_pull_on(QUEUE*, void*);
void visualize_int_queue(QUEUE*q);
void visualize_lexem_queue(QUEUE q);
void visualize_Inst_queue(QUEUE q);
void visualize_Inst_Op_queue(QUEUE q);
void* defiler(QUEUE* q);
void free_queue(QUEUE *q);

#endif
