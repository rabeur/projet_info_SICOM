/**
 * @file lex.h
 * @author François Portet <francois.portet@imag.fr>
 * @brief Lexem-related stuff.
 *
 * Contains lexem types definitions, some low-level syntax error codes,
 * the lexem structure definition and the associated prototypes.
 */

#ifndef _LEX_H_
#define _LEX_H_

#include <LEXEM.h>
#include <QUEUE.h>
#include <stdio.h>



char* 	getNextToken( char** , char* );
void type_lexem(LEXEM* lexem);
QUEUE create_lexem_queue(char* path);


#endif /* _LEX_H_ */
