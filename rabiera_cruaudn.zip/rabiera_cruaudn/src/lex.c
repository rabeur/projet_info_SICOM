
/**
 * @file lex.c
 * @author François Portet <francois.portet@imag.fr>
 * @brief Lexical analysis routines for MIPS assembly syntax.
 *
 * These routines perform the analysis of the lexeme of an assembly source code file.
 */

#define _POSIX_C_SOURCE 200112L
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <strings.h>
#include <LEXEM.h>
#include <QUEUE.h>
#include <TEST_FUNCTIONS.h>
#include <LIST.h>

#include <global.h>
#include <notify.h>
#include <lex.h>

#define S_SIZE 4096
#define STR_SIZE 200
#define COMPONENT_SIZE 512

/* ATTENTION: getNextToken est juste un exemple -> il est à recoder completement !!! */
/**
 * @param token The pointeur to the lexeme to be extracted.
 * @param current_line The address from which the analysis must be performed.
 * @return the address at which the analysis stopped or NULL if the analysis is terminated.
 * @brief This function get an input line, extracts a token from it and return the pointeur to the next place where the analysis should continue.
 */

/* note that MIPS assembly supports distinctions between lower and upper case*/
char*  getNextToken(char** token, char* current_line){
    char* start = current_line;
    char* end=NULL;
    int token_size=0;
    /*printf("1\n");*/
    /* check input parameter*/
    if (current_line == NULL) return NULL;
    /*printf("2\n");*/
    /* eats any blanks,  before the token*/
    while ((*start!='\0') && (*start!='\n') && (isblank(*start)))
    {
	     start++;
    }
    /* go till next blank or end*/
    end=start;
    /*printf("start = %s",start);*/
    /* si le lexem commence par un hastag alors jusqu'à la fin de la ligne, tout les mots font partie du meme commentaire, on finit donc le mots qu'en présence d'une fin de ligne ou de texte*/
    if (*end == '#')
    {
      while((*end !='\0') && (*end !='\n'))
        {
          end++;
        }
    /*printf("comment\n");*/
    }
    /* si le caractère est un caractère spécifique qui permet d'identifier un type de lexem, il est isolé*/
    else if((*end == ',') || (*end == '(') || (*end==')') || (*end == ':') || (*end =='"'))
    {
      end++;
      /*printf("symbole\n");*/
    }
    else if (*end =='\\')
    {
      end ++;
      end ++;
      /*printf("slash\n");*/
    }
    else if((*end =='\0') || (*end=='\n'))
    {
      /*printf("fin_text\n");*/
      end=start;
    }
        /*Si le caractère est quelconque alors le "lexem" sera crée jusqu'à atteindre un caractère de séparation caratère si dessus + espace */
    else
    {
        /* ici un problème a été d'avoir des opérateur logique OU inclusif au lieu de OU eclusif (a creuser)*/
        while ((*end!='\0') && (*end != '\n') && (isblank(*end) == 0) && (*end !=',') && (*end !='(') && (*end !=')') && (*end !=':') && (*end !='"') &&
        (*end  !='#') && (*end !='\\'))
        {
	         end++;
        }
        /*printf("autre\n");*/
    }
    /*printf("end = %s\n",end);*/
    /*compute size : if zero there is no more token to extract*/
    token_size=end-start;
    /*printf("token_size = %d\n",token_size);*/
    if (token_size>0)
    {
	     *token 	= calloc(token_size+1,sizeof(*start));
	      strncpy(*token,start,token_size);
	       (*token)[token_size]='\0';
	        return end;
    }
    else
    {
      *token 	= calloc(token_size+1,sizeof(*start));
       strncpy(*token,start,token_size);
        (*token)[token_size]='\0';
      return NULL;
    }

}

/*test de chaque lexem afin de le classer dans une liste de type définit au préalable dans LEXEM.h*/
int type_lexem(LEXEM* lexem){
  int test=0;
  switch (*(lexem->content)){
    case '#':
          test_commentaire(lexem);
          break;
    case '.':
           test_dot(lexem);
          break;
    case '$':
          test_registre(lexem);
          break;
    case ',':
          test_coma(lexem);
          break;
    case '(':
          test_parento(lexem);
          break;
    case ')':
          test_parentc(lexem);
          break;
    case '0':
           test_nombre(lexem);
          break;
    case '1':
          test_nombre(lexem);
          break;
    case '2':
          test_nombre(lexem);
          break;
    case '3':
          test_nombre(lexem);
          break;
    case '4':
          test_nombre(lexem);
          break;
    case '5':
          test_nombre(lexem);
          break;
    case '6':
          test_nombre(lexem);
          break;
    case '7':
          test_nombre(lexem);
          break;
    case '8':
          test_nombre(lexem);
          break;
    case '9':
          test_nombre(lexem);
          break;
    case '-':
          test_nombre(lexem);
          break;
    case '+':
          test_nombre(lexem);
          break;
    case '\n':
          test_NL(lexem);
          break;
    case'\0':
          test_FT(lexem);
          break;
    case '\"':
          test_guil(lexem);
          break;
    /*rajouté le cas '\' cependant nous ne savons pas encore l'implémenter correctement*/
    default:
          test_mots(lexem);
          break;
  }
  if (lexem->type ==9)
  {
    test=1;
    printf("lexem de type inconnue\n");
    return test;
  }
  return test;
}

QUEUE create_lexem_queue(char* path){
  FILE *f1 ;
  f1 = fopen(path,"r");
  int test=0;
  char* token; char s[S_SIZE]; char* flag; char* endline;
  QUEUE q;   /*future liste contenant les lexem*/
  int i=1, j=1;   /* indicateur de la ligne du lexem*/
  q = create_QUEUE(); /*file qui contient tous les pointeurs sur les lexems étudiés*/

  if (f1 == NULL)
  {
    ERROR_MSG("error file empty");
    return q;
  }
  flag = fgets(s,STR_SIZE,f1);  /*permet de savoir si on arrive a lire le fichier */
  if (flag != NULL)
  {
    do{
      endline = getNextToken(&token,s );
      if (endline != NULL)
      { /* Ajout du lexem contenu dans token dans la file*/
         LEXEM* lex=new_lexem(token, EMPTY, i,j);
         test = type_lexem(lex);
         if (test ==1)
           {
             printf("ERROR : Lexem ligne %d est inconnue\n",i);
             return q;
           }
         queue_pull_on(&q,lex);
         j += 1;
         do{ /*ici ajout du lexem contenu dans token dans la file*/
            endline = getNextToken(&token,endline);
            LEXEM* lex=new_lexem(token, EMPTY, i,j);
            test = type_lexem(lex);
            if (test ==1)
              {
                printf("ERROR : Lexem ligne %d est inconnue\n",i);
                return q;
              }
            queue_pull_on(&q,lex);
            j += 1;
         } while((endline != NULL));/*j a modifier pour les tests*/
      }
      flag = fgets(s,STR_SIZE,f1);
      i +=1;/* ligne du fichier*/
      j=1;
    } while ((flag !=NULL));/*i a modifier pour les test */
   }
  fclose(f1);  /*on ferme le fichier .s ouvert auparavant*/
  /*On ajoute le LEXEM "fin de texte" : '\0' à notre file afin de la compléter*/
  LEXEM* lex=new_lexem("", EMPTY, i,j);  /*la ligne du lex est i ou i-1, i+1, 0?*/
  memset(lex->content, '\0', COMPONENT_SIZE);
  test = type_lexem(lex);
  if (test ==1)
    {
      printf("Lexem ligne %d est inconnue\n",i);
      return q;
    }
  queue_pull_on(&q,lex);
  return q;
}

MAILLON* create_Maill(int type,char content[512], MAILLON* mprec){
  MAILLON *m=calloc(1,sizeof(*m)); /* ) */
  LEXEM* lex=new_lexem(content, type, 0,0);
  m->pdata=lex;
  mprec->next = m;
  return m;
}

void pseudo_NOP(MAILLON* M, int* test){
  if (((LEXEM*)M->next->pdata)->type == 10){
    MAILLON* End = M->next;
    strcpy(((LEXEM*)M->pdata)->content , "SLL"); /* NOP -> SLL $0, $0, 0 */

    MAILLON* m1 = create_Maill( 5,"$0",  M);

    MAILLON* m2 = create_Maill( 6,",",  m1);

    MAILLON* m3 = create_Maill( 5, "$0",  m2);

    MAILLON* m4 = create_Maill( 6,",",   m3);

    MAILLON* m5 = create_Maill( 4,"0",  m4);

    m5->next = End;
    *test=0;
  }
  else {
    *test = 1;
    printf("Opérande de NOP mal rentrée\n");
  }
}

void pseudo_LW(MAILLON* M, int* test){
  char* Op1 = ((LEXEM*)M->next->pdata)->content ;
  char* Op2 = ((LEXEM*)M->next->next->next->pdata)->content ;

  if ((((LEXEM*)M->next->next->next->next->pdata)->type == 10) && (((LEXEM*)M->next->next->next->next->pdata)->lign == ((LEXEM*)M->pdata)->lign)){
    MAILLON* End = ((MAILLON*)M->next->next->next)->next;
      strcpy(((LEXEM*)M->pdata)->content , "LUI"); /* LW  $rt, target -> LUI $rt, upper_16(target)\n
                                                                        LW $rt, lower_16(target)($rt)\n*/
    MAILLON* m1 = create_Maill( 5, Op1,   M);

    MAILLON* m2= create_Maill(6, ",",   m1);

    MAILLON* m3 = create_Maill( 4, "16", m2);

    MAILLON* m4 = create_Maill( 12,"(",  m3);

    MAILLON* m5 = create_Maill( 4,Op2, m4);

    MAILLON* m6 = create_Maill( 13,")",  m5);

    MAILLON* m7= create_Maill( 10, "\0",   m6);

    MAILLON* m8 = create_Maill( 7, "LW",  m7);

    MAILLON* m9 = create_Maill( 5,Op1,  m8);

    MAILLON* m10= create_Maill( 6,",",   m9);

    MAILLON* m11 = create_Maill(4,"-16",  m10);

    MAILLON* m12 = create_Maill( 12, "(",  m11);

    MAILLON* m13 = create_Maill( 4,Op2,   m12);

    MAILLON* m14 = create_Maill( 13,")",   m13);

    MAILLON* m15 = create_Maill( 12, "(", m14);

    MAILLON* m16 = create_Maill( 4, Op1, m15);

    MAILLON* m17 = create_Maill( 13, ")",  m16);

    m17->next = End;

   *test=0;
  }
  else {
    *test = 0;
    /*printf("Opérande de LW mal rentrée\n");*/
  }
}

void pseudo_SW(MAILLON* M, int* test){
  char* Op1 = ((LEXEM*)M->next->pdata)->content ;
  char* Op2 = ((LEXEM*)M->next->next->next->pdata)->content ;

  if ((((LEXEM*)M->next->next->next->next->pdata)->type == 10) && (((LEXEM*)M->next->next->next->next->pdata)->lign == ((LEXEM*)M->pdata)->lign)){
    MAILLON* End = ((MAILLON*)M->next->next->next)->next;
    strcpy(((LEXEM*)M->pdata)->content , "LUI"); /* SW  $rt, target -> LUI $at, upper_16(target)\n
                                                     LW $rt, lower_16(target)($at)\n*/
    MAILLON* m1 = create_Maill( 5, "$at",    M);

    MAILLON* m2= create_Maill(6, ",",  m1);

    MAILLON* m3 = create_Maill( 4, "16", m2);

    MAILLON* m4 = create_Maill( 12,"(",  m3);

    MAILLON* m5 = create_Maill( 4,Op2, m4);

    MAILLON* m6 = create_Maill( 13,")", m5);

    MAILLON* m7= create_Maill( 10, "\0", m6);

    MAILLON* m8 = create_Maill( 7, "SW",  m7);

    MAILLON* m9 = create_Maill( 5,Op1,  m8);

    MAILLON* m10= create_Maill( 6,",",  m9);

    MAILLON* m11 = create_Maill(4,"-16",  m10);

    MAILLON* m12 = create_Maill( 12, "(",  m11);

    MAILLON* m13 = create_Maill( 4,Op2, m12);

    MAILLON* m14 = create_Maill( 13,")",   m13);

    MAILLON* m15 = create_Maill( 12, "(", m14);

    MAILLON* m16 = create_Maill( 4,"$at",  m15);

    MAILLON* m17 = create_Maill( 13, ")",  m16);

    m17->next = End;
    *test=0;
  }
  else {
    *test = 0;
    /*printf("Opérande de SW mal rentrée\n");*/
  }
}

void pseudo_MOVE(MAILLON* M, int* test){
  char* Op1 = ((LEXEM*)M->next->pdata)->content ;
  char* Op2 = ((LEXEM*)M->next->next->next->pdata)->content ;

  if (((LEXEM*)M->next->next->next->next->pdata)->type == 10){
    MAILLON* End = ((MAILLON*)M->next->next->next)->next;
    strcpy(((LEXEM*)M->pdata)->content , "ADD"); /* MOVE  $rt, $rs -> ADD $rt, $rs, $zero\n*/

    MAILLON* m1 = create_Maill( 5,Op1, M);

    MAILLON* m2 = create_Maill( 6,",", m1);

    MAILLON* m3 = create_Maill( 5, Op2,  m2);

    MAILLON* m4 = create_Maill( 6,",",  m3);

    MAILLON* m5 = create_Maill( 5,"$0",  m4);

    m5->next = End;
    *test=0;
  }
  else {
    *test = 1;
    printf("Opérande de MOVE mal rentrée\n");
  }
}

void pseudo_NEG(MAILLON* M, int* test){
  char* Op1 = ((LEXEM*)M->next->pdata)->content ;
  char* Op2 = ((LEXEM*)M->next->next->next->pdata)->content ;

  if (((LEXEM*)M->next->next->next->next->pdata)->type == 10){
    MAILLON* End = ((MAILLON*)M->next->next->next)->next;
    strcpy(((LEXEM*)M->pdata)->content , "SUB"); /* NEG $rt, $rs -> SUB $rt, $zero, $rs*/

    MAILLON* m1 = create_Maill( 5,Op1, M);

    MAILLON* m2 = create_Maill( 6,",", m1);

    MAILLON* m3 = create_Maill( 5, "$0",  m2);

    MAILLON* m4 = create_Maill( 6,",",  m3);

    MAILLON* m5 = create_Maill( 5,Op2, m4);

    m5->next = End;
    *test=0;
  }
  else {
    *test = 1;
    printf("Opérande de NEG mal rentrée\n");
  }
}

void pseudo_LI(MAILLON* M, int* test){
  char* Op1 = ((LEXEM*)M->next->pdata)->content ;
  char* Op2 = ((LEXEM*)M->next->next->next->pdata)->content ;

  if (((LEXEM*)M->next->next->next->next->pdata)->type == 10){
    MAILLON* End = ((MAILLON*)M->next->next->next)->next;
    strcpy(((LEXEM*)M->pdata)->content , "ADDI"); /* LI $rt, immeidate -> ADDI $rt, $zero, immediate\n*/

    MAILLON* m1 = create_Maill( 5,Op1,  M);

    MAILLON* m2 = create_Maill( 6,",", m1);

    MAILLON* m3 = create_Maill( 5, "$0",  m2);

    MAILLON* m4 = create_Maill( 6,",", m3);

    MAILLON* m5 = create_Maill( 4,Op2,  m4);

    m5->next = End;
    *test=0;
  }
  else {
    *test = 1;
    printf("Opérande de LI mal rentrée\n");
  }
}

void pseudo_BLT(MAILLON* M, int* test){
  char* Op1 = ((LEXEM*)M->next->pdata)->content ;
  char* Op2 = ((LEXEM*)M->next->next->next->pdata)->content ;
  char* Op3 = ((LEXEM*)M->next->next->next->next->next->pdata)->content ;

  if (((LEXEM*)M->next->next->next->next->next->next->pdata)->type == 10){
    MAILLON* End = ((MAILLON*)M->next->next->next->next->next)->next;
    strcpy(((LEXEM*)M->pdata)->content , "SLT"); /* BLT  $rt, $rs, target -> SLT $1, $rt, $rs\n
                                                                             BNE $1, $zero, target\n*/
    MAILLON* m1 = create_Maill( 5,"$1",   M);

    MAILLON* m2= create_Maill(6, ",",  m1);

    MAILLON* m3 = create_Maill( 5, Op1, m2);

    MAILLON* m4 = create_Maill( 6,",",  m3);

    MAILLON* m5 = create_Maill( 5,Op2,  m4);

    MAILLON* m6 = create_Maill( 10,"\0", m5);

    MAILLON* m7= create_Maill( 7, "BNE",   m6);

    MAILLON* m8 = create_Maill( 5, "$1",  m7);

    MAILLON* m9 = create_Maill( 6,",",  m8);

    MAILLON* m10= create_Maill( 5,"$0",  m9);

    MAILLON* m11 = create_Maill(6,",",  m10);

    MAILLON* m12 = create_Maill( 4, Op3,  m11);

    m12->next = End;
    *test=0;
  }
  else {
    *test = 1;
    printf("Opérande de BLT mal rentrée\n");
  }
}

void find_and_modif_pseudoinst (MAILLON* m, int* test ){ /* penser a free() les maillons laisser à l'abandon*/
  MAILLON* M=m->next;
  char dico_pseudo[7][10]={"NOP","LW","SW","MOVE","NEG","LI","BLT"};
  int i=0; int a;
  char* s=((LEXEM*)m->pdata)->content;
  /*printf("s= %s  dico_pseudo[0] = %s  cmpa= %d\n",s,dico_pseudo[0],strcasecmp(s,dico_pseudo[0]));*/
  /*printf("type data = %d\n",((LEXEM*)m->pdata)->type);*/
  if (((LEXEM*)m->pdata)->type==7){
    for(i=0;i<7;i++){
      /*printf("tab[i]=%s   ",tab[i].nom);*/
      a = strcasecmp(s,dico_pseudo[i]);
      /*printf ("a = %d\n",a);*/
      if (a == 0){
          switch(i){

            case 0:
             pseudo_NOP(m, test);
             if (m->next != NULL){
               find_and_modif_pseudoinst (M, test);
             }
             return ;
            break;

            case 1:
             pseudo_LW(m, test);
             if (m->next != NULL){
               find_and_modif_pseudoinst (M, test);
             }
             return ;
            break;

            case 2:
             pseudo_SW(m, test);
             if (m->next != NULL){
               find_and_modif_pseudoinst (M, test);
             }
             return ;
            break;

            case 3:
             pseudo_MOVE(m, test);
             if (m->next != NULL){
               find_and_modif_pseudoinst (M, test);
             }
             return ;
            break;

            case 4:
             pseudo_NEG(m, test);
             if (m->next != NULL){
               find_and_modif_pseudoinst (M, test);
             }
             return ;
            break;

            case 5:
             pseudo_LI(m, test);
             if (m->next != NULL){
               find_and_modif_pseudoinst (M,  test);
             }
             return ;
            break;

            case 6:
            pseudo_BLT(m, test);
            if (m->next != NULL){
              find_and_modif_pseudoinst (M, test);
            }
            return ;
            break;

            default:
            printf("erreur dans la def de tab[i]\n");
            *test = 1;
            break;
          }
        }
      }
    }
    if (m->next != NULL){
      find_and_modif_pseudoinst (M, test);
    }
    return ;
}

void normalisation_lignes(MAILLON* m){
  int i=1;
  int j=1;
  while (m->next != NULL){
    while(((LEXEM*)m->pdata)->type != 10){
      ((LEXEM*)m->pdata)->lign=i;
      ((LEXEM*)m->pdata)->num=j;
      j++;
      m=m->next;
    }
    ((LEXEM*)m->pdata)->lign=i;
    ((LEXEM*)m->pdata)->num=j;
    m=m->next;
    j++;
    i++;
    }
    ((LEXEM*)m->pdata)->lign=i;
    ((LEXEM*)m->pdata)->num=j;
    return;
  }
