#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>

#include <global.h>
#include <notify.h>
#include <lex.h>

#include <LEXEM.h>
#include <QUEUE.h>
#include <TEST_FUNCTIONS.h>
#include <LIST.h>
#include <STRUCT.h>
#include <COLLECT.h>
#include <Dico.h>




inst_def_t* lect_dico_int(char* nomFichierDico, int* p_nb_inst) {
  /*Charge le ficheier dictionnaire nomFichierDico*/
  /*Retourne un pointeur sur le tableau dictionnaire*/
  /*Stocke le nb d'instructions dans *p_nb_inst*/

  int i;
  char s1[512];
  inst_def_t *tab;
  FILE* f1=fopen(nomFichierDico,"r");
  if(f1==NULL){
        return NULL;
      }
  if( fscanf(f1,"%d", p_nb_inst) != 1) {
      return NULL;
    }
    tab=calloc(*p_nb_inst,sizeof(*tab));
    if(tab==NULL) return NULL;
    for (i=0;i<*p_nb_inst;i++){
    if(fscanf(f1,"%s %c %d",s1,&(tab[i].type),&(tab[i].nb_op))!=3){
        free(tab);
        ERROR_MSG("tableau non comforme ligne i : %d\n", i);
        return NULL;
      }
      tab[i].nom=strdup(s1);
      /*printf("tab[%d] :.nom = %s  .type = %c  .nb_op = %d \n",i,tab[i].nom,tab[i].type,tab[i].nb_op);*/
    }
    fclose(f1);
    return tab;
}
