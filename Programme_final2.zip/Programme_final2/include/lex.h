/**
 * @file lex.h
 * @author François Portet <francois.portet@imag.fr>
 * @brief Lexem-related stuff.
 *
 * Contains lexem types definitions, some low-level syntax error codes,
 * the lexem structure definition and the associated prototypes.
 */

#ifndef _LEX_H_
#define _LEX_H_

#include <LEXEM.h>
#include <QUEUE.h>
#include <stdio.h>
#include <Dico.h>



char* 	getNextToken( char** , char* );
int type_lexem(LEXEM* lexem);
QUEUE create_lexem_queue(char* path);
void find_and_modif_pseudoinst (MAILLON* m, int* test);
void pseudo_NOP(MAILLON* M, int* test);
void pseudo_LW(MAILLON* M, int* test);
void pseudo_SW(MAILLON* M, int* test);
void pseudo_MOVE(MAILLON* M, int* test);
void pseudo_NEG(MAILLON* M, int* test);
void pseudo_LI(MAILLON* M, int* test);
void pseudo_BLT(MAILLON* M, int* test);
MAILLON* create_Maill(int type,char* content, MAILLON* mprec);
void normalisation_lignes(MAILLON* m);

#endif /* _LEX_H_ */
