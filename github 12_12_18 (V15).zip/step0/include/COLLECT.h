#ifndef _COLLECT
#define _COLLECT

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>

#include <global.h>
#include <notify.h>
#include <lex.h>

#include <LEXEM.h>
#include <QUEUE.h>
#include <TEST_FUNCTIONS.h>
#include <LIST.h>
#include <STRUCT.h>
#include <Dico.h>

instruction* add_inst(char * content,int i , int lign,int* shift_inst, inst_def_t* tab);
QUEUE add_symb(QUEUE l, char* content, int lign, int shift);
int recherche_instruction(char* content,inst_def_t* tab,int NbDefInstructions, int* i);
int modif_Op_inst(instruction* p_inst,LIST p );
int recherche_Op_c1(LIST p,instruction* p_inst);
int recherche_Op_c2(LIST p,instruction* p_inst);
int recherche_Op_c3(LIST p,instruction* p_inst);
int def_type_Op(DATA_OP_INST* Op);
int test_inst(instruction* p_inst, inst_def_t* tab);
int extract_Op(instruction* p_inst);
int extract_reg(DATA_OP_INST* Op);
int extract_reg_sp(char* s,DATA_OP_INST* Op,int val );
#endif
