#ifndef _STRUCT
#define _STRUCT

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>

#include <global.h>
#include <notify.h>


typedef enum {
    BYTE,
    WORD,
    ASCIIZ,
    /*LABEL,*/
    SPACE  } OPTYPE;

typedef enum {
      INT,
      LABEL } WORDTYPE;

typedef struct{
  WORDTYPE wtype;
  union{
        int word_nb;
        char* word_label;
  } WORD;
} WORD_TAG;

typedef struct{
    OPTYPE type;
    union{
      char byte;
      WORD_TAG word;
      char* asciiz;
      unsigned int space;
    } VAL;} DATA_OP;

/*-----Maillon collection instruction------*/
typedef enum {
    REG, /*0*/
    BASE_OFFSET,/*1*/
    NOMBRE,/*2*/
    SYMBOL,/*3*/
    RIEN,/*4*/
    PAS_INIT/*5*/} OPTYPE_INST;

typedef struct{
    OPTYPE_INST type;
    char* VAL;} DATA_OP_INST;

typedef struct{
  char nom[512];
  char inst_type;
  int nb_op;
  int lign;
  int shift;
  DATA_OP_INST Op1;
  DATA_OP_INST Op2;
  DATA_OP_INST Op3;}instruction;

/*-------Maillon collec data et bss-----------*/
/*typedef enum {
    word,
    byte,
    space
  } DATA_TYPE;
*/
typedef struct{
/*  DATA_TYPE data_type;*/
  DATA_OP op;
  int lign;
  int shift;
} DATA;

/*Table symbole (table de hachage ou liste) contient les etiquette et le decallage par rapport au debut de section*/
typedef struct{
  char* content;
  int lign;
  int shift;
}SYMB;

/*On va stocker uniquement des primitives .space, on ne cree donc pas de composante type_primitive */
typedef struct{
  char* op;
  int lign;
  int shift;
}BSS_ELEM;
#endif
