#ifndef _STRUCT_COLL
#define _STRUCT_COLL

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>

#include <global.h>
#include <notify.h>
#include <lex.h>

#include <LEXEM.h>
#include <QUEUE.h>
#include <TEST_FUNCTIONS.h>
#include <LIST.h>
#include <STRUCT.h>
#include <COLLECT.h>
#include <Dico.h>

typedef enum {
      INIT,

      IS_SPACE,
      IS_BYTE,
      IS_SYMB,
      IS_WORD,
      IS_ASCIIZ,

      IS_OP_BYTE,
      IS_OP_SYMB,
      IS_OP_WORD,
      IS_OP_ASCIIZ,

      ERROR,
      END_DATA
      } DATA_STATE;

typedef struct {
      LEXEM* p_directive;
      LEXEM* p_op;
      int lign;
      int shift;} DATA_S;


typedef struct{
      char* content;
      int lign;
      int shift;}SYMB_S;

#endif
