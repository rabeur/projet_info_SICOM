#ifndef _TEST_TYPE
#define _TEST_TYPE
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>

#include <global.h>
#include <notify.h>
#include <lex.h>
#include <LIST.h>

int is_dot_space_n(LIST* p_l_lex, QUEUE* p_q);
int is_dot_primData_op(LIST* p_l_lex,QUEUE* p_q);

int coma_then_op_byte(LIST p,QUEUE* p_q);
int coma_then_op_word(LIST p,QUEUE* p_q);
int coma_then_op_asciiz(LIST p,QUEUE* p_q);
int coma_then_op_space(LIST p,QUEUE* p_q);

int coma_then_n(LIST p,QUEUE* p_q);
#endif
