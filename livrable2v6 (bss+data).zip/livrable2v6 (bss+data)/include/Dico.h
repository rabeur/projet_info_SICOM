#ifndef _DICO_H_
#define _DICO_H_

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>

#include <global.h>
#include <notify.h>
#include <lex.h>

#include <LEXEM.h>
#include <QUEUE.h>
#include <TEST_FUNCTIONS.h>
#include <LIST.h>
#include <STRUCT.h>
#include <COLLECT.h>



typedef struct {char * nom; char type; int nb_op ;} inst_def_t;
inst_def_t* lect_dico_int(char* nomFichierDico, int* p_nb_inst);

#endif
