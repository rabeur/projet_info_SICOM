#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>

#include <global.h>
#include <notify.h>
#include <lex.h>

#include <LEXEM.h>
#include <QUEUE.h>
#include <TEST_FUNCTIONS.h>
#include <LIST.h>
#include <STRUCT.h>
#include <COLLECT.h>
#include <Dico.h>

/*QUEUE add_symb(QUEUE l, char* content, int lign, int shift){
  SYMB* p_symb = calloc(1,sizeof(*p_symb));

  p_symb->content = calloc(strlen(content)+1, sizeof(char));
  strcpy(p_symb->content,content);

  p_symb->lign=lign;

  p_symb->shift=shift;

  QUEUE ppair = calloc(1,sizeof(*ppair));
  ppair->pdata = p_symb;
  ppair->next = l;

  return ppair;
}

*/
/*Modifie une file à partir d'un pointeur, la fonction créé un symbole
à partir de content, lign et détermine elle même le shift. Ce symbole est
ajouter au debut de la file.
Ne RENVOIE rien.
*/
void add_symb(QUEUE* p_q, char* content, int lign){
  SYMB* p_symb = calloc(1,sizeof(*p_symb));
  int shift;

  p_symb->content = strdup(content);
  p_symb->lign=lign;

  if(p_q->first==NULL) {shift=0;}
  else {
    MAILLON *p = p_q->first;
    while (p->next != NULL){p = p->next;}
    shift=((SYMB*)(p->pdata))->shift+4;}

  p_symb->shift=shift;

  queue_pull_on(p_q,p_symb);
}

void add_bss_elem(QUEUE* p_q, char* op, int lign){
  BSS_ELEM* p_bss = calloc(1,sizeof(*p_bss));
  int shift;

  p_bss->op = strdup(op);
  p_bss->lign=lign;

  if(p_q->first==NULL) {shift=0;}
  else {
    MAILLON *p = p_q->first;
    while (p->next != NULL){p = p->next;}
    shift=((BSS_ELEM*)(p->pdata))->shift+4;}

  p_bss->shift=shift;

  queue_pull_on(p_q,p_bss);
}

DATA_OP* create_DATA_OP_byte(char byte){
  DATA_OP* p_op = calloc(1,sizeof(*p_op));
  p_op->type=BYTE;
  p_op->VAL.byte=byte;
  return p_op;
}
DATA_OP* create_DATA_OP_word_nb(int word){
  DATA_OP* p_op = calloc(1,sizeof(*p_op));
  p_op->type=WORD;
  p_op->VAL.word.wtype=INT;
  p_op->VAL.word.WORD.word_nb=word;
  return p_op;
}
DATA_OP* create_DATA_OP_word_label(char* word){
  DATA_OP* p_op = calloc(1,sizeof(*p_op));
  p_op->type=WORD;
  p_op->VAL.word.wtype=LABEL;
  p_op->VAL.word.WORD.word_label=strdup(word);
  return p_op;
}
DATA_OP* create_DATA_OP_asciiz(char* asciiz){
  DATA_OP* p_op = calloc(1,sizeof(*p_op));
  p_op->type=ASCIIZ;
  p_op->VAL.asciiz=strdup(asciiz);
  return p_op;
}
DATA_OP* create_DATA_OP_space(unsigned int space){
  DATA_OP* p_op = calloc(1,sizeof(*p_op));
  p_op->type=SPACE;
  p_op->VAL.space=space;
  return p_op;
}



void add_data_elem(QUEUE* p_q, DATA_OP op, int lign){ /*Vérifier si les décallage valent tj 4*/
  DATA* pdata = calloc(1,sizeof(*pdata));
  int shift;

  OPTYPE type=op.type;

  pdata->op.type = type;

  if (type==BYTE){
        pdata->op.VAL.byte = op.VAL.byte;}
  if (type==WORD){
        if(pdata->op.VAL.word.wtype==INT){
              pdata->op.VAL.word.WORD.word_nb = op.VAL.word.WORD.word_nb;}
        if(pdata->op.VAL.word.wtype==LABEL){
              pdata->op.VAL.word.WORD.word_label = op.VAL.word.WORD.word_label;}
  }
  if (type==ASCIIZ){
        pdata->op.VAL.asciiz = strdup(op.VAL.asciiz);}
  if (type==SPACE){
        pdata->op.VAL.space = op.VAL.space;}

  pdata->lign=lign;

  if(p_q->first==NULL) {shift=0;}
  else {
    MAILLON *p = p_q->first;
    while (p->next != NULL){p = p->next;}
    shift=((DATA*)(p->pdata))->shift+4;}

  pdata->shift=shift;

  queue_pull_on(p_q,pdata);
}

/*Vérifie si la chaine de caractere content est dans le dictionnaire d'instruction tab
RENVOIE 0 si ce n'est pas le cas
RENVOIE 1 si l'instruction est trouvé et insere dans i l'indice de l'instruction trouvée
*/
int recherche_instruction(char* content,inst_def_t* tab,int NbDefInstructions,int* i)
{
  int j =0; int a=0;
  do {
    if (!strcmp(content, tab[j].nom)) {a=1; /*printf("\na = 1\n");*/}
    j++;
  } while(j<NbDefInstructions && a==0);
  /*printf("\nContent = %s , a = %d, i = %d\n",content,a,j  );*/
  *i=j;
  return a;
}



instruction* add_inst(char* content, int i , int lign, int* shift_inst, inst_def_t* tab){
  instruction* p_inst = calloc(1,sizeof(instruction));

  strcpy(p_inst->nom,(tab[i].nom));

  p_inst->inst_type=tab[i].type;

  p_inst->nb_op = tab[i].nb_op;

  p_inst->lign=lign;

  *shift_inst+=4;
  p_inst->shift=*shift_inst;

  /* On remarque avec ce printf que la structure p_inst est bien remplie comme désiré*/
  /*printf("|| nom = %s || type = %c || nb_op = %d || lign = %d || shift = %d || Op1.type = %d || Op2.type = %d || Op3.type = %d ||\n",p_inst->nom, p_inst->inst_type, p_inst->nb_op, p_inst->lign, p_inst->shift,(int*)p_inst->Op1.type,(int*)p_inst->Op2.type,(int*)p_inst->Op3.type);*/

  return p_inst;
}

void modif_Op_inst(instruction* p_inst){

  switch (p_inst->nb_op) {
    case 0:
    p_inst->Op1.type=RIEN;
    p_inst->Op2.type=RIEN;
    p_inst->Op3.type=RIEN;
    break;

    case 1:
    /*p=p->next;
    LEXEM* p_lex=((LEXEM*)(p->pdata));
    int type = p_lex->type;*/
    p_inst->Op1.type=PAS_INIT;
    p_inst->Op2.type=RIEN;
    p_inst->Op3.type=RIEN;
    break;

    case 2:
    p_inst->Op1.type=PAS_INIT;
    p_inst->Op2.type=PAS_INIT;
    p_inst->Op3.type=RIEN;
    break;

    case 3:
    p_inst->Op1.type=PAS_INIT;
    p_inst->Op2.type=PAS_INIT;
    p_inst->Op3.type=PAS_INIT;
    break;

    default:
    printf("\n||  ERROR nb_op  ||\n");
    break;}

}
