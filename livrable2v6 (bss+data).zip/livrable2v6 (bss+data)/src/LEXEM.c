#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include <LEXEM.h>

#define COMPONENT_SIZE 512

LEXEM* new_lexem(char* content, lextype type, int lign, int num){
  LEXEM* lex=calloc(1,sizeof(LEXEM));
  lex->lign=lign;
  lex->num=num;
  lex->type=type;
  memset(lex->error, '\0', COMPONENT_SIZE);
  strcpy(lex->content, content);
  return lex;
}
