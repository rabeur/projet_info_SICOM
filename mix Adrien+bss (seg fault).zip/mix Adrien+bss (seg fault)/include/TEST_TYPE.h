#ifndef _TEST_TYPE
#define _TEST_TYPE
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>

#include <global.h>
#include <notify.h>
#include <lex.h>
#include <LIST.h>

int is_dot_space_n(LIST* p_l_lex, QUEUE* p_q);

#endif
