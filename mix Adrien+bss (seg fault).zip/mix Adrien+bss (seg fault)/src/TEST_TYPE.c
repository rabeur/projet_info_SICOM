#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>

#include <global.h>
#include <notify.h>
#include <lex.h>

#include <LEXEM.h>
#include <QUEUE.h>
#include <TEST_FUNCTIONS.h>
#include <LIST.h>
#include <STRUCT.h>
#include <COLLECT.h>
#include <Dico.h>
#include <TEST_TYPE.h>

/*Verifie si à partir du lexem actuel on a un .space n ou .space n1,...,nn correct,
si oui renvoie 1 et modifie le pointeur de liste
sinon renvoie 0 sans modifier le pointeur*/
int is_dot_space_n(LIST* p_l_lex,QUEUE* p_q){

  LIST p=*p_l_lex;
  LEXEM* p_lex=((LEXEM*)(p->pdata));

  if(strcmp(p_lex->content,".space")==0){

      p=p->next;
      p_lex=((LEXEM*)(p->pdata));
      if(p_lex->type==VAL_DECIMAL){
          add_bss_elem(p_q, p_lex->content, p_lex->lign);
          p=p->next;
          p_lex=((LEXEM*)(p->pdata));

          while(coma_then_n(p,p_q)){
              p=p->next->next;
              p_lex=((LEXEM*)(p->pdata));
          }
          *p_l_lex=p;
          return 1;
      }
      else{
        printf("Erreur: argument invalide pour .space (l'opérande n'est une une valeur décimale)- ligne %d\n",p_lex->lign);
        return 0;
      }
  }
  else{return 0;}/*si ca commence pas par .space c'est pas forcement une erreur */
}


int coma_then_n(LIST p,QUEUE* p_q){  /*(QUEUE* p_q, char* op, int lign)*/
  if((((LEXEM*)(p->pdata))->type)==COMA){
    LEXEM* p_lex=((LEXEM*)(p->next->pdata));
    if((p_lex->type)==VAL_DECIMAL){
      add_bss_elem(p_q, p_lex->content, p_lex->lign);
      return 1;
    }
    printf("Erreur: argument invalide pour .space (vigule en trop ou manque une valeur décimale)- ligne %d\n",p_lex->lign);
    return 0;
  }
    return 0;
}
