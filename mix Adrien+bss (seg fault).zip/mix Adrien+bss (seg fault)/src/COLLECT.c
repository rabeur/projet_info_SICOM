#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>

#include <global.h>
#include <notify.h>
#include <lex.h>

#include <LEXEM.h>
#include <QUEUE.h>
#include <TEST_FUNCTIONS.h>
#include <LIST.h>
#include <STRUCT.h>
#include <COLLECT.h>
#include <Dico.h>

int recherche_instruction(char* content,inst_def_t* tab,int NbDefInstructions,int* i){
  int j =0; int a=0;
  do {
    if (strcasecmp(content, tab[j].nom)==0) a=1;
    j++;
  } while(j<NbDefInstructions && a==0);
  *i=j;
  return a;
}


instruction* add_inst(char* content, int i , int lign, int* shift_inst, inst_def_t* tab){
  instruction* p_inst = calloc(1,sizeof(instruction));
  strcpy(p_inst->nom,(tab[i].nom));
  p_inst->inst_type=tab[i].type;
  p_inst->nb_op = tab[i].nb_op;
  p_inst->lign=lign;
  *shift_inst+=4;
  p_inst->shift=*shift_inst;

  DATA_OP_INST* Op1 = calloc(1,sizeof(DATA_OP_INST));
  DATA_OP_INST* Op2 = calloc(1,sizeof(DATA_OP_INST));
  DATA_OP_INST* Op3 = calloc(1,sizeof(DATA_OP_INST));
  p_inst->Op1=Op1;
  p_inst->Op2=Op2;
  p_inst->Op3=Op3;
  p_inst->Op1->VAL_INST=NULL;
  p_inst->Op1->nb_Lex=NULL;
  p_inst->Op1->type=5;
  p_inst->Op2->type=5;
  p_inst->Op2->VAL_INST=NULL;
  p_inst->Op2->nb_Lex=NULL;
  p_inst->Op3->type=5;
  p_inst->Op3->VAL_INST=NULL;
  p_inst->Op3->nb_Lex=NULL;
  /* On remarque avec ce printf que la structure p_inst est bien remplie comme désiré*/
  return p_inst;
}

int modif_Op_inst(instruction* p_inst,LIST p){
  int test=0;
  switch (p_inst->nb_op) {
    case 0:
    ((DATA_OP_INST*)p_inst->Op1)->type=RIEN;
    ((DATA_OP_INST*)p_inst->Op2)->type=RIEN;
    ((DATA_OP_INST*)p_inst->Op3)->type=RIEN;
    break;

    case 1:
    test = recherche_Op_c1(p,p_inst);
    ((DATA_OP_INST*)p_inst->Op2)->type=RIEN;
    ((DATA_OP_INST*)p_inst->Op3)->type=RIEN;
    break;

    case 2:
    test = recherche_Op_c2(p,p_inst);
    ((DATA_OP_INST*)p_inst->Op3)->type=RIEN;
    break;

    case 3:
    test = recherche_Op_c3(p,p_inst);
    break;

    default:
    printf("||  ERROR nb_op  ||\n");
    test = 1;
    return test;
    break;
  }
  return test;
  }

int recherche_Op_c1(LIST p,instruction* p_inst){

  /* INIT */

    QUEUE* q1 = calloc(1,sizeof(QUEUE));
    *q1=create_QUEUE();
    int k=0; /* compte le nb d'opérande dans la ligne */
    int i=0;
    int test =0;
    p=p->next;
    LEXEM* p_lex=((LEXEM*)(p->pdata));
    int lign =p_lex->lign;
    int ligna =p_lex->lign;
    int T=0;
    if (p_lex->type!=10) {
      T=1;
    }
    else{
        printf("\nERROR too less argument for this instruction\n");
        ((DATA_OP_INST*)p_inst->Op1)->type = 4;
        test = 1;
        return test;
        }

    /* debut boucle */
    while (T!=0){
      k++;
      switch (k){
        i=0;
        case 1:
        while(T!=0 && lign==lign)
        {
            queue_pull_on(q1,p_lex);
            p=p->next;
            p_lex=((LEXEM*)(p->pdata));
            ligna =p_lex->lign;
            T=1;
            i++;
            if (p_lex->type==10) T=0;
            if (p_lex->type==6){
              T=0;
              printf("\nERROR too much argument for this instruction\n");
              test = 1;
              return test;
              break;
            }
        }
        ((DATA_OP_INST*)p_inst->Op1)->nb_Lex=i;
        ((DATA_OP_INST*)p_inst->Op1)->VAL_INST = q1;
        def_type_Op(((DATA_OP_INST*)p_inst->Op1));
        break;

        default:
        printf("\nERROR too much argument for this instruction\n");
        test = 1;
        return test;
        break;
        }
    }
    return test;
  }

int recherche_Op_c2(LIST p,instruction* p_inst){

  /* INIT */
    QUEUE* q1 = calloc(1,sizeof(QUEUE));
    QUEUE* q2 = calloc(1,sizeof(QUEUE));
    *q1=create_QUEUE();
    *q2=create_QUEUE();
    int k=0; /* compte le nb d'opérande dans la ligne */
    int i=0;
    int test =0;
    p=p->next;
    LEXEM* p_lex=((LEXEM*)(p->pdata));
    int lign =p_lex->lign;
    int ligna =p_lex->lign;
    int T=0;
    if (p_lex->type!=10) {
      T=1;
      }
    else{
      ((DATA_OP_INST*)p_inst->Op1)->type = 4;
      ((DATA_OP_INST*)p_inst->Op2)->type = 4;
      test = 1;
      return test;
      }
    /* debut boucle */
    while (T!=0){
      k++;
      switch (k){
        case 1:
        i=0;
          while(T!=0 && ligna==lign)
          {
              queue_pull_on(q1,p_lex);
              p=p->next;
              p_lex=((LEXEM*)(p->pdata));
              ligna =p_lex->lign;
              T=1;
              i++;
              if (p_lex->type==6) T=0;
              if (p_lex->type==10){
                T=0;
                printf("\nERROR too less argument for this instruction\n");
                break;
              }
          }
          ((DATA_OP_INST*)p_inst->Op1)->nb_Lex=i;
          ((DATA_OP_INST*)p_inst->Op1)->VAL_INST = q1;
          def_type_Op(((DATA_OP_INST*)p_inst->Op1));
          p=p->next;
          p_lex=((LEXEM*)(p->pdata));
          ligna =p_lex->lign;
          if (p_lex->type!=10 && ligna ==lign) T=1;
          else{
              ((DATA_OP_INST*)p_inst->Op2)->type = 4;
              test = 1;
              return test;
          }
          break;

        case 2:
        i=0;
          while(T!=0 && ligna==lign){
              queue_pull_on(q2,p_lex);
              p=p->next;
              p_lex=((LEXEM*)(p->pdata));
              ligna =p_lex->lign;
              T=1;
              i++;
              if (p_lex->type==10) T=0;
              if (p_lex->type==6){
                T=0;
                printf("\nERROR too much argument for this instruction\n");
                test = 1;
                return test;
                break;
              }
          }
          ((DATA_OP_INST*)p_inst->Op2)->nb_Lex=i;
          ((DATA_OP_INST*)p_inst->Op2)->VAL_INST = q2;
          def_type_Op(((DATA_OP_INST*)p_inst->Op2));
          break;

        default:
          printf("ERROR too much argument for this instruction\n");
          test = 1;
          return test;
          break;
        }
    }
    return test;
}

int recherche_Op_c3(LIST p,instruction* p_inst){

  /* INIT */
    QUEUE* q1 = calloc(1,sizeof(QUEUE));
    QUEUE* q2 = calloc(1,sizeof(QUEUE));
    QUEUE* q3 = calloc(1,sizeof(QUEUE));
    *q1=create_QUEUE();
    *q2=create_QUEUE();
    *q3=create_QUEUE();
    int k=0; /* compte le nb d'opérande dans la ligne */
    int i =0;
    int test =0;
    p=p->next;
    LEXEM* p_lex=((LEXEM*)(p->pdata));
    int lign =p_lex->lign;
    int ligna =p_lex->lign;
    int T=0;
    if (p_lex->type!=10) {
      T=1;
      }
    else{
      ((DATA_OP_INST*)p_inst->Op1)->type = 4;
      ((DATA_OP_INST*)p_inst->Op2)->type = 4;
      ((DATA_OP_INST*)p_inst->Op3)->type = 4;
      test = 1;
      return test;
      }
    /* debut boucle */
    while (T!=0){
      k++;
      switch (k){
        case 1:
        i=0;
          while(T!=0 && ligna==lign)
          {
              queue_pull_on(q1,p_lex);
              p=p->next;
              p_lex=((LEXEM*)(p->pdata));
              ligna =p_lex->lign;
              T=1;
              i++;
              if (p_lex->type==6) T=0;
              if (p_lex->type==10){
                T=0;
                printf("\nERROR too less argument for this instruction\n");
                test = 1;
                return test;
                break;
              }
          }
          ((DATA_OP_INST*)p_inst->Op1)->nb_Lex=i;
          ((DATA_OP_INST*)p_inst->Op1)->VAL_INST = q1;
          def_type_Op(((DATA_OP_INST*)p_inst->Op1));
          p=p->next;
          p_lex=((LEXEM*)(p->pdata));
          ligna =p_lex->lign;
          if (p_lex->type!=10 && ligna ==lign) T=1;
          else{
              ((DATA_OP_INST*)p_inst->Op2)->type = 4;
              ((DATA_OP_INST*)p_inst->Op3)->type = 4;
              test = 1;
              return test;
          }
          break;

        case 2:
        i=0;
          while(T!=0 && ligna==lign)
          {
              queue_pull_on(q2,p_lex);
              p=p->next;
              p_lex=((LEXEM*)(p->pdata));
              ligna =p_lex->lign;
              T=1;
              i++;
              if (p_lex->type==6) T=0;
              if (p_lex->type==10){
                T=0;
                printf("\nERROR too less argument for this instruction\n");
                test = 1;
                return test;
                break;
              }
          }
          ((DATA_OP_INST*)p_inst->Op2)->nb_Lex=i;
          ((DATA_OP_INST*)p_inst->Op2)->VAL_INST = q2;
          def_type_Op(((DATA_OP_INST*)p_inst->Op2));
          p=p->next;
          p_lex=((LEXEM*)(p->pdata));
          ligna =p_lex->lign;
          if (p_lex->type!=10 && ligna ==lign) T=1;
          else{
              ((DATA_OP_INST*)p_inst->Op3)->type = 4;
              test = 1;
              return test;
          }
          break;

        case 3:
          i=0;
          while(T!=0 && ligna==lign)
          {
              queue_pull_on(q3,p_lex);
              p=p->next;
              p_lex=((LEXEM*)(p->pdata));
              ligna =p_lex->lign;
              T=1;
              i++;
              if (p_lex->type==10 ) T=0;
              if (p_lex->type==6){
                T=0;
                printf("\nERROR too much argument for this instruction\n");
                test = 1;
                return test;
                break;
              }
          }
          ((DATA_OP_INST*)p_inst->Op3)->nb_Lex=i;
          ((DATA_OP_INST*)p_inst->Op3)->VAL_INST = q3;
          def_type_Op(((DATA_OP_INST*)p_inst->Op3));
          break;

        default:
          printf("ERROR too much argument for this instruction\n");
          test = 1;
          return test;
          break;
        }
      }

      return test;
}

int def_type_Op(DATA_OP_INST* Op){
  QUEUE* q= Op->VAL_INST;
  MAILLON* M=q->first;
  LEXEM* L=M->pdata;
  lextype T=L->type;
  char tab_enum[16][20]={"COMMENT","NL","SYMBOLE","DIRECTIVE","VAL_DECIMAL","REGISTRE","COMA","STRING","VAL_HEXA","ERROR","FT","GUIL","PARENTO","PARENTC","DOT","EMPTY"};
  int nb_lex=Op->nb_Lex;
  int j=0;
  int a=0;
  int OFFSET[5]={4,8,12,5,13};
  if (nb_lex==1){
      if (T==5 ) {
        Op->type=REG  ;
        return EXIT_SUCCESS;
        }

      if(T==4 || T==8){
        Op->type=NOMBRE;
        return EXIT_SUCCESS;
      }
      if (T==7)
      {
        Op->type = SYMBOL;
        return EXIT_SUCCESS;
      }
    else{return 1;}
  }
  if (nb_lex ==4){
    if(j==0){
      if(T==OFFSET[0] || T==OFFSET[1]){
        a=1;}
      else{return 1;}
    }

    for (j=1;j<4;j++){
      M=M->next;
      L=M->pdata;
      T=L->type;
        if (T==OFFSET[j+1]) {a=1;}
        else{return 1;}
    }
  }
  if(a==1){Op->type=BASE_OFFSET;}
  else{return 1;}
}

int test_inst(instruction* p_inst,inst_def_t* tab){
  int j;
  int a=0;
  int nb_op = p_inst->nb_op;
  int test=0;
  for (j=0;j<11;j++){
    if (strcasecmp(p_inst->nom, tab[j].nom)==0) a=1;
  }
  for (j=11;j<13;j++){
    if (strcasecmp(p_inst->nom, tab[j].nom)==0) a=2;
  }
  for (j=13;j<15;j++){
    if (strcasecmp(p_inst->nom, tab[j].nom)==0) a=6;
  }
  for (j=15;j<19;j++){
    if (strcasecmp(p_inst->nom, tab[j].nom)==0) a=3;
  }
  for (j=19;j<22;j++){
    if (strcasecmp(p_inst->nom, tab[j].nom)==0) a=4;
  }
  for (j=22;j<24;j++){
    if (strcasecmp(p_inst->nom, tab[j].nom)==0) a=5;
  }
  switch(a){

    case 1: /* full registre */
      switch(nb_op){

        case 1:
          if(((DATA_OP_INST*)p_inst->Op1)->type!=0){
            printf("mauvais type d'opérande 1 pour cette instruction\n");
            test =1;
            return test;
          }
        break;

        case 2:
          if(((DATA_OP_INST*)p_inst->Op1)->type!=0){
            printf("mauvais type d'opérande 1 pour cette instruction\n");
            test =1;
            return test;
          }
          if(((DATA_OP_INST*)p_inst->Op2)->type!=0){
            printf("mauvais type d'opérande 2 pour cette instruction\n");
            test =1;
            return test;
          }
        break;

        case 3:
          if(((DATA_OP_INST*)p_inst->Op1)->type!=0){
            printf("mauvais type d'opérande 1 pour cette instruction\n");
            test =1;
            return test;
          }
          if(((DATA_OP_INST*)p_inst->Op2)->type!=0){
            printf("mauvais type d'opérande 2 pour cette instruction\n");
            test =1;
            return test;
          }
          if(((DATA_OP_INST*)p_inst->Op3)->type!=0){
            printf("mauvais type d'opérande 3 pour cette instruction\n");
            test =1;
            return test;
          }
        break;

        default:
          printf("mauvais nombre d'opérande pour cette instruction\n");
          test =1;
          return test;
        break;
      }
    break;

    case 2: /* registre + immediate */
      switch(nb_op){

        case 2:
          if(((DATA_OP_INST*)p_inst->Op1)->type!=0){
            printf("mauvais type d'opérande 1 pour cette instruction\n");
            test =1;
            return test;
          }
          if(((DATA_OP_INST*)p_inst->Op2)->VAL1>32767 && ((DATA_OP_INST*)p_inst->Op2)->VAL1<-32768){ /* gerer le faite que ce soit un immédiate*/
            printf("mauvais type d'opérande 2 pour cette instruction\n");
            return 1;
          }
        break;

        case 3:
          if(((DATA_OP_INST*)p_inst->Op1)->type!=0){
            printf("mauvais type d'opérande 1 pour cette instruction\n");
            test =1;
            return test;
          }
          if(((DATA_OP_INST*)p_inst->Op2)->type!=0){
            printf("mauvais type d'opérande 2 pour cette instruction\n");
            test =1;
            return test;
          }
          if(((DATA_OP_INST*)p_inst->Op3)->VAL1>32767 && ((DATA_OP_INST*)p_inst->Op3)->VAL1<-32768){ /* gerer le faite que ce soit un immédiate*/
            printf("mauvais type d'opérande 3 pour cette instruction\n");
            test =1;
            return test;
          }
        break;

        default:
          printf("mauvais nombre d'opérande pour cette instruction\n");
          test =1;
          return test;
        break;
      }
    break;

    case 6: /* registre + BASE_offset */
        switch(nb_op){

        case 2:
          if(((DATA_OP_INST*)p_inst->Op1)->type!=0){
            printf("mauvais type d'opérande 1 pour cette instruction\n");
            test =1;
            return test;test =1;
            return test;
          }
          if(((DATA_OP_INST*)p_inst->Op2)->VAL1>32767 && ((DATA_OP_INST*)p_inst->Op2)->VAL1<-32768 && ((DATA_OP_INST*)p_inst->Op2)->VAL2>=32 && ((DATA_OP_INST*)p_inst->Op2)->VAL2<0){
            printf("mauvais type d'opérande 2 pour cette instruction\n");
            test =1;
            return test;
          }
        break;

        default:
          printf("mauvais nombre d'opérande pour cette instruction\n");
          test =1;
          return test;
        break;
        }
    break;

    case 3: /* registre + relatif (offset) attention a la division par 4*/
      switch(nb_op){

        case 2:
          if(((DATA_OP_INST*)p_inst->Op1)->type!=0){
            printf("mauvais type d'opérande 1 pour cette instruction\n");
            test =1;
            return test;
          }
          if(((DATA_OP_INST*)p_inst->Op2)->VAL1>131072 && ((DATA_OP_INST*)p_inst->Op2)->VAL1<-131073 && ((DATA_OP_INST*)p_inst->Op2)->VAL1%4 !=0){
            printf("mauvais type d'opérande 2 pour cette instruction\n");
            test =1;
            return test;
          }
        break;

        case 3:
          if(((DATA_OP_INST*)p_inst->Op1)->type!=0){
            printf("mauvais type d'opérande 1 pour cette instruction\n");
            test =1;
            return test;
          }
          if(((DATA_OP_INST*)p_inst->Op2)->type!=0){
            printf("mauvais type d'opérande 2 pour cette instruction\n");
            test =1;
            return test;
          }
          if(((DATA_OP_INST*)p_inst->Op3)->VAL1>131072 && ((DATA_OP_INST*)p_inst->Op3)->VAL1<-131073 && ((DATA_OP_INST*)p_inst->Op3)->VAL1%4 !=0){ /* gerer le faite que ce soit un immédiate*/
            printf("mauvais type d'opérande 3 pour cette instruction\n");
            test =1;
            return test;
          }
        break;

        default:
          printf("mauvais nombre 'opérande pour cette instruction\n");
          test =1;
          return test;
        break;
      }
    break;

    case 4: /* registre + sa */
      switch(nb_op){

        case 3:
          if(((DATA_OP_INST*)p_inst->Op1)->type!=0){
            printf("mauvais type d'opérande 1 pour cette instruction\n");
            test =1;
            return test;
          }
          if(((DATA_OP_INST*)p_inst->Op2)->type!=0){
            printf("mauvais type d'opérande 2 pour cette instruction\n");
            test =1;
            return test;
          }
          if(((DATA_OP_INST*)p_inst->Op3)->VAL1<0 && ((DATA_OP_INST*)p_inst->Op3)->VAL1>=32){ /* gerer le faite que ce soit un sa*/
            printf("mauvais type d'opérande 3 pour cette instruction\n");
            test =1;
            return test;
          }
        break;

        default:
          printf("mauvais type d'opérande pour cette instruction\n");
          test =1;
          return test;
          break;
      }
    break;

    case 5: /* target attention a la division par 4*/
      switch(nb_op){

        case 1:
          if(((DATA_OP_INST*)p_inst->Op1)->VAL1>134217728 && ((DATA_OP_INST*)p_inst->Op1)->VAL1<-134217729 && ((DATA_OP_INST*)p_inst->Op1)->VAL1%4 !=0){ /* gerer le fait que ce soit une taget */
            printf("mauvais type d'opérande 1 pour cette instruction\n");
            test =1;
            return test;
          }
        break;

        default:
            printf("mauvais nombre d'opérande pour cette instruction\n");
            test =1;
            return test;
        break;
      }
    break;

    default:
        printf("mauvais nom pour cette instruction\n");
        test =1;
        return test;
    break;

  }

  return test;
}

int extract_Op(instruction* p_inst){
  /* on transforme les opérande des instruction d'un string a un int comme attendue pour la suite */
  int test =0;
  char* s;
  int nb_op = p_inst->nb_op;
  switch(nb_op){
    case 1:
      if (((DATA_OP_INST*)p_inst->Op1)->type == 1){
        s =(((LEXEM*)((MAILLON*)((QUEUE*)((DATA_OP_INST*)p_inst->Op1)->VAL_INST)->first)->pdata)->content);
        ((DATA_OP_INST*)p_inst->Op1)->VAL1 = strtol (s,NULL,0);
        s=((MAILLON*)((MAILLON*)((MAILLON*)((QUEUE*)((DATA_OP_INST*)p_inst->Op1)->VAL_INST)->first)->next)->next)->pdata;
        extract_reg_sp(s,p_inst->Op1, 2);
      }
      else if(((DATA_OP_INST*)p_inst->Op1)->type == 0){
        ((DATA_OP_INST*)p_inst->Op1)->VAL2 = NULL;
        test = extract_reg((DATA_OP_INST*)p_inst->Op1);
      }
      else{
        ((DATA_OP_INST*)p_inst->Op1)->VAL2 = NULL;
        s =(((LEXEM*)((MAILLON*)((QUEUE*)((DATA_OP_INST*)p_inst->Op1)->VAL_INST)->first)->pdata)->content);
        ((DATA_OP_INST*)p_inst->Op1)->VAL1 = strtol (s,NULL,0);
      }
      break;

    case 2:
      if (((DATA_OP_INST*)p_inst->Op1)->type == 1){
        s =(((LEXEM*)((MAILLON*)((QUEUE*)((DATA_OP_INST*)p_inst->Op1)->VAL_INST)->first)->pdata)->content);
        ((DATA_OP_INST*)p_inst->Op1)->VAL1 = strtol (s,NULL,0);
        s=(((LEXEM*)((MAILLON*)((MAILLON*)((MAILLON*)((QUEUE*)((DATA_OP_INST*)p_inst->Op1)->VAL_INST)->first)->next)->next)->pdata)->content);
        extract_reg_sp(s,p_inst->Op1, 2);
      }
      else if(((DATA_OP_INST*)p_inst->Op1)->type == 0){
        ((DATA_OP_INST*)p_inst->Op1)->VAL2 = NULL;
        test = extract_reg((DATA_OP_INST*)p_inst->Op1);
      }
      else{
        ((DATA_OP_INST*)p_inst->Op1)->VAL2 = NULL;
        s =(((LEXEM*)((MAILLON*)((QUEUE*)((DATA_OP_INST*)p_inst->Op1)->VAL_INST)->first)->pdata)->content);
        ((DATA_OP_INST*)p_inst->Op1)->VAL1 = strtol (s,NULL,0);
      }
      if (((DATA_OP_INST*)p_inst->Op2)->type == 1){
        s =(((LEXEM*)((MAILLON*)((QUEUE*)((DATA_OP_INST*)p_inst->Op2)->VAL_INST)->first)->pdata)->content);
        ((DATA_OP_INST*)p_inst->Op2)->VAL1 = strtol (s,NULL,0);
        s=(((LEXEM*)((MAILLON*)((MAILLON*)((MAILLON*)((QUEUE*)((DATA_OP_INST*)p_inst->Op2)->VAL_INST)->first)->next)->next)->pdata)->content);
        extract_reg_sp(s,p_inst->Op2, 2);
      }
      else if(((DATA_OP_INST*)p_inst->Op2)->type == 0){
        ((DATA_OP_INST*)p_inst->Op2)->VAL2 = NULL;
        test = extract_reg((DATA_OP_INST*)p_inst->Op2);
      }
      else{
        ((DATA_OP_INST*)p_inst->Op2)->VAL2 = NULL;
        s =(((LEXEM*)((MAILLON*)((QUEUE*)((DATA_OP_INST*)p_inst->Op2)->VAL_INST)->first)->pdata)->content);
        ((DATA_OP_INST*)p_inst->Op2)->VAL1 = strtol (s,NULL,0);
      }
    break;

    case 3:
      if (((DATA_OP_INST*)p_inst->Op1)->type == 1){
        s =(((LEXEM*)((MAILLON*)((QUEUE*)((DATA_OP_INST*)p_inst->Op1)->VAL_INST)->first)->pdata)->content);
        ((DATA_OP_INST*)p_inst->Op1)->VAL1 = strtol (s,NULL,0);
        s=(((LEXEM*)((MAILLON*)((MAILLON*)((MAILLON*)((QUEUE*)((DATA_OP_INST*)p_inst->Op1)->VAL_INST)->first)->next)->next)->pdata)->content);
        extract_reg_sp(s,p_inst->Op1, 2);
      }
      else if(((DATA_OP_INST*)p_inst->Op1)->type == 0){
        ((DATA_OP_INST*)p_inst->Op1)->VAL2 = NULL;
        test = extract_reg((DATA_OP_INST*)p_inst->Op1);
      }
      else{
        ((DATA_OP_INST*)p_inst->Op1)->VAL2 = NULL;
        s =(((LEXEM*)((MAILLON*)((QUEUE*)((DATA_OP_INST*)p_inst->Op1)->VAL_INST)->first)->pdata)->content);
        ((DATA_OP_INST*)p_inst->Op1)->VAL1 = strtol (s,NULL,0);
      }
      if (((DATA_OP_INST*)p_inst->Op2)->type == 1){
        s =(((LEXEM*)((MAILLON*)((QUEUE*)((DATA_OP_INST*)p_inst->Op2)->VAL_INST)->first)->pdata)->content);
        ((DATA_OP_INST*)p_inst->Op2)->VAL1 = strtol (s,NULL,0);
        s=(((LEXEM*)((MAILLON*)((MAILLON*)((MAILLON*)((QUEUE*)((DATA_OP_INST*)p_inst->Op2)->VAL_INST)->first)->next)->next)->pdata)->content);
        extract_reg_sp(s,p_inst->Op2, 2);
      }
      else if(((DATA_OP_INST*)p_inst->Op2)->type == 0){
        ((DATA_OP_INST*)p_inst->Op2)->VAL2 = NULL;
        test = extract_reg((DATA_OP_INST*)p_inst->Op2);
      }
      else{
        ((DATA_OP_INST*)p_inst->Op2)->VAL2 = NULL;
        s =(((LEXEM*)((MAILLON*)((QUEUE*)((DATA_OP_INST*)p_inst->Op2)->VAL_INST)->first)->pdata)->content);
        ((DATA_OP_INST*)p_inst->Op2)->VAL1 = strtol (s,NULL,0);
      }
      if (((DATA_OP_INST*)p_inst->Op3)->type == 1){
        s =(((LEXEM*)((MAILLON*)((QUEUE*)((DATA_OP_INST*)p_inst->Op3)->VAL_INST)->first)->pdata)->content);
        ((DATA_OP_INST*)p_inst->Op3)->VAL1 = strtol (s,NULL,0);
        s=(((LEXEM*)((MAILLON*)((MAILLON*)((MAILLON*)((QUEUE*)((DATA_OP_INST*)p_inst->Op3)->VAL_INST)->first)->next)->next)->pdata)->content);
        extract_reg_sp(s,p_inst->Op3, 2);
      }
      else if(((DATA_OP_INST*)p_inst->Op3)->type == 0){
        ((DATA_OP_INST*)p_inst->Op3)->VAL2 = NULL;
        test = extract_reg((DATA_OP_INST*)p_inst->Op3);
      }
      else{
        ((DATA_OP_INST*)p_inst->Op3)->VAL2 = NULL;
        s =(((LEXEM*)((MAILLON*)((QUEUE*)((DATA_OP_INST*)p_inst->Op3)->VAL_INST)->first)->pdata)->content);
        ((DATA_OP_INST*)p_inst->Op3)->VAL1 = strtol (s,NULL,0);
      }
    break;

    default:
      test=1;
      return test;
      break;
  }
 return test;
}

int extract_reg(DATA_OP_INST* Op){
  int test=0;
  char* s;
  int val =1;
  if(Op->type == 0){

    s =(((LEXEM*)((MAILLON*)((QUEUE*)Op->VAL_INST)->first)->pdata)->content);
    test = extract_reg_sp(s, Op, val);
  }

    else{
      printf("registre mal rentré \n");
      test = 1;
      return test;
  }
  return test;
}

int extract_reg_sp(char* s,DATA_OP_INST* Op,int val){
    int test =0;
    int r;

    if (strcasecmp(s, "$0")==0){
      r=0;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    if (strcasecmp(s, "$1")==0){
      r=1;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    if (strcasecmp(s, "$2")==0){
      r=2;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    if (strcasecmp(s, "$3")==0){
      r=3;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    if (strcasecmp(s, "$4")==0){
      r=4;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    if (strcasecmp(s, "$5")==0){
      r=5;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    if (strcasecmp(s, "$6")==0){
      r=6;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    if (strcasecmp(s, "$7")==0){
      r=7;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    if (strcasecmp(s, "$8")==0){
      r=8;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    if (strcasecmp(s, "$9")==0){
      r=9;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    if (strcasecmp(s, "$10")==0){
      r=10;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    if (strcasecmp(s, "$11")==0){
      r=11;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    if (strcasecmp(s, "$12")==0){
      r=12;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    if (strcasecmp(s, "$13")==0){
      r=13;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    if (strcasecmp(s, "$14")==0){
      r=14;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    if (strcasecmp(s, "$15")==0){
      r=15;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    if (strcasecmp(s, "$16")==0){
      r=16;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    if (strcasecmp(s, "$17")==0){
      r=17;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    if (strcasecmp(s, "$18")==0){
      r=18;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    if (strcasecmp(s, "$19")==0){
      r=19;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    if (strcasecmp(s, "$20")==0){
      r=20;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    if (strcasecmp(s, "$21")==0){
      r=21;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    if (strcasecmp(s, "$22")==0){
      r=22;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
        return test;
  }

    if (strcasecmp(s, "$23")==0){
      r=23;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    if (strcasecmp(s, "$24")==0){
      r=24;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    if (strcasecmp(s, "$25")==0){
      r=25;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    if (strcasecmp(s, "$26")==0){
      r=26;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    if (strcasecmp(s, "$27")==0){
      r=27;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    if (strcasecmp(s, "$28")==0){
      r=28;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    if (strcasecmp(s, "$29")==0){
      r=29;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    if (strcasecmp(s, "$30")==0){
      r=30;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    if (strcasecmp(s, "$31")==0){
      r=31;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    if (strcasecmp(s, "$zero")==0){
      r=0;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    if (strcasecmp(s, "$at")==0){
      r=1;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    if (strcasecmp(s, "$v0")==0){
      r=2;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    if (strcasecmp(s, "$v1")==0){
      r=3;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    if (strcasecmp(s, "$a0")==0){
      r=4;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}        test = 0;
        return test;
  }

    if (strcasecmp(s, "$a1")==0){
      r=5;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}        test = 0;
        return test;
  }

    if (strcasecmp(s, "$a2")==0){
      r=6;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    if (strcasecmp(s, "$a3")==0){
      r=7;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    if (strcasecmp(s, "$t0")==0){
      r=8;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    if (strcasecmp(s, "$t1")==0){
      r=9;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    if (strcasecmp(s, "$t2")==0){
      r=10;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    if (strcasecmp(s, "$t3")==0){
      r=11;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    if (strcasecmp(s, "$t4")==0){
      r=12;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    if (strcasecmp(s, "$t5")==0){
      r=13;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}        test = 0;
    return test;
  }

    if (strcasecmp(s, "$t6")==0){
      r=14;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    if (strcasecmp(s, "$t7")==0){
      r=15;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    if (strcasecmp(s, "$s0")==0){
      r=16;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    if (strcasecmp(s, "$s1")==0){
      r=17;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}        test = 0;
        return test;
  }

    if (strcasecmp(s, "$s2")==0){
      r=18;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    if (strcasecmp(s, "$s3")==0){
      r=19;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    if (strcasecmp(s, "$s4")==0){
      r=20;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    if (strcasecmp(s, "$s5")==0){
      r=21;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    if (strcasecmp(s, "$s6")==0){
      r=22;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    if (strcasecmp(s, "$s7")==0){
      r=23;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    if (strcasecmp(s, "$t8")==0){
      r=24;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    if (strcasecmp(s, "$t9")==0){
      r=25;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    if (strcasecmp(s, "$k0")==0){
      r=26;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    if (strcasecmp(s, "$k1")==0){
      r=27;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    if (strcasecmp(s, "$gp")==0){
      r=28;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}        test = 0;
        return test;
  }

    if (strcasecmp(s, "$sp")==0){
      r=29;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    if (strcasecmp(s, "$fp")==0){
      r=30;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    if (strcasecmp(s, "$ra")==0){
      r=31;
      if (val ==1){Op->VAL1=r;} if (val==2){Op->VAL2=r;} if(val != 1 && val !=2 ){test=1; return test;}      test = 0;
      return test;
  }

    else{
        printf("registre mal rentré \n");
        test = 1;
  }
}


/*Modifie une file à partir d'un pointeur, la fonction créé un symbole
à partir de content, lign et détermine elle même le shift. Ce symbole est
ajouter au debut de la file.
Ne RENVOIE rien.
*/
void add_symb(QUEUE* p_q, char* content, int lign){
  SYMB* p_symb = calloc(1,sizeof(*p_symb));
  int shift;

  p_symb->content = strdup(content);
  p_symb->lign=lign;

  if(p_q->first==NULL) {shift=0;}
  else {
    MAILLON *p = p_q->first;
    while (p->next != NULL){p = p->next;}
    shift=((SYMB*)(p->pdata))->shift+4;}

  p_symb->shift=shift;

  queue_pull_on(p_q,p_symb);
}

void add_bss_elem(QUEUE* p_q, char* op, int lign){
  BSS_ELEM* p_bss = calloc(1,sizeof(*p_bss));
  int shift;

  p_bss->op = strdup(op);
  p_bss->lign=lign;

  if(p_q->first==NULL) {shift=0;}
  else {
    MAILLON *p = p_q->first;
    while (p->next != NULL){p = p->next;}
    shift=((BSS_ELEM*)(p->pdata))->shift+4;}

  p_bss->shift=shift;

  queue_pull_on(p_q,p_bss);
}
