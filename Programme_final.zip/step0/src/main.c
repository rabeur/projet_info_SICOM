#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>

#include <global.h>
#include <notify.h>
#include <lex.h>

#include <LEXEM.h>
#include <QUEUE.h>
#include <TEST_FUNCTIONS.h>
#include <LIST.h>
#include <STRUCT.h>
#include <COLLECT.h>
#include <Dico.h>


int main(int agrc, char* argv[])
{  /*Creation de la file de lexem à partir d'un fichier*/
  /*printf("argv[0]= %s\n",argv[1]);*/
  if(agrc!=2){ERROR_MSG("Fichier passé en paramètre inexistant ou non valide");}
  char* path=strdup(argv[1]);
/*  strcat(path,"miam_sujet.s*/
  int test_pseudo;
  int i;/*permetra de connaitre le numero du lexem*/
  int NbDefInstructions = 0 ;
  inst_def_t* tab = lect_dico_int("tests/DICO_INSTRUCTION.txt",&NbDefInstructions);
  QUEUE q=create_lexem_queue(path);
  /*QUEUE l=q;
  printf("step1\n");
  visualize_lexem_queue(l);*/
  find_and_modif_pseudoinst(q.first,&test_pseudo);
  /*QUEUE l=q;
  printf("step1\n");
  visualize_lexem_queue(l);*/
  normalisation_lignes(q.first);
  if (test_pseudo ==1){
    printf("pseudo intruction mal remplie\n");
    return EXIT_FAILURE;
  }
  /*QUEUE l=q;
  printf("step1\n");
  visualize_lexem_queue(l);*/
  /*printf("\n|| fin INI || \n\n");*/

/*---------------------------------------------------*/

  /*printf("NbDefInstructions = %d\n",NbDefInstructions);
  for (i=0;i <NbDefInstructions;i++)
  {
    printf("tab[%d] :.nom = %s  .type = %c  .nb_op = %d \n",i,tab[i].nom,tab[i].type,tab[i].nb_op);
  }*/
  QUEUE collec_instruct=create_QUEUE();
  QUEUE collec_data=create_QUEUE();
  QUEUE collec_bss=create_QUEUE();
  QUEUE collec_symb=create_QUEUE(); /*choisir liste ou table de symbol*/
  /*QUEUE table_symb=create_QUEUE();*/

  int shift_txt=0;
  /*int shift_data=0;*/
  /*int shift_bss=0;*/

  int test_instr;
  int test_bss;
  int test_data;
  /*LIST liste_lexem=create_list();*/
  int k=0;
  int inst_num=0;
  MAILLON* p=(MAILLON*)(q.first);/*liste_lexem;*/
/*puts("step1\n");*/
  for (;p->next!=NULL;p=p->next){

    LEXEM* p_lex=((LEXEM*)(p->pdata));
    /*printf("ligne : %d | num : %d | content: %s \n",p_lex->lign,p_lex->num,p_lex->content);*/
    lextype type=p_lex->type;

  /*  char t_type[16][20]={"COMMENT","NL","SYMBOLE","DIRECTIVE","VAL_DECIMAL","REGISTRE","COMA","STRING","VAL_HEXA","ERROR","FT","GUIL","PARENTO","PARENTC","DOT","EMPTY"};*/


    switch(type) {
        case DIRECTIVE :
        /*___________BSS PART__________*/

         if(strcmp(p_lex->content,".bss")==0){
           test_bss =collection_bss( p,&collec_bss, &collec_symb);
           if (test_bss == 0)
           {
             printf("ERROR .BSS élément ligne %d : mal rentrée",((LEXEM*)p->pdata)->lign);
             return EXIT_FAILURE;
           }
         }
         /*___________DATA PART__________*/
         else if(strcmp(p_lex->content,".data")==0){
             test_data =collection_data( p,&collec_data, &collec_symb);
             if (test_data == 0)
             {
               printf("ERROR .DATA élément ligne %d : mal rentrée",((LEXEM*)p->pdata)->lign);
               return EXIT_FAILURE;
             }
         }
         break;

        case STRING :

            i=0;
            /*printf("C'est une chaine de caract\n" );*/
            if (recherche_instruction(p_lex->content,tab,NbDefInstructions,&i) == 1){
              printf("c'est une instruction\n");
              inst_num ++;
              instruction* p_inst =  add_inst( p_lex->content, i-1, p_lex->lign, &shift_txt, tab);
              /*printf("Etape d'analyse 1\n");*/
              test_instr = modif_Op_inst(p_inst,p);
              if(test_instr==1){
                printf("\nInstruction ligne = %d || mal appelée_1\n",p_inst->lign);
                return EXIT_FAILURE;
              }
              test_instr = extract_Op(p_inst);
              if(test_instr==1){
                printf("\nInstruction ligne = %d || mal appelée_2\n",p_inst->lign);
                return EXIT_FAILURE;
              }
              test_instr = test_inst(p_inst,tab); /*ne traite pas des cas des base offset() des pseudo-instruc*/
              if(test_instr==1){
                printf("\nInstruction ligne = %d || mal appelée_3\n",p_inst->lign);
                return EXIT_FAILURE;
              }
              /*printf("Etape d'analyse 2\n");*/

              queue_pull_on(&collec_instruct, p_inst );
              /*printf("instruction %d: [nom = %s | type = %c | nb_op =   %d | lign = %i | shift = %d \n",inst_num, p_inst -> nom , p_inst -> inst_type,p_inst -> nb_op, p_inst-> lign,p_inst -> shift);
              printf("Oprérande 1 : type = %d || VAL1 = %d || VAL2 = %d\n",p_inst->Op1->type, p_inst->Op1->VAL1, p_inst->Op1->VAL2);
              printf("Oprérande 2 : type = %d || VAL1 = %d || VAL2 = %d\n",p_inst->Op2->type, p_inst->Op2->VAL1, p_inst->Op2->VAL2);
              printf("Oprérande 3 : type = %d || VAL1 = %d || VAL2 = %d\n",p_inst->Op3->type, p_inst->Op3->VAL1, p_inst->Op3->VAL2);*/



            }
            break;

            default :
             printf("C'est pas dans l'enum lextype\n" );
             return EXIT_FAILURE;
             break;
         }
         k++;
       }

DEBUG_MSG("================AFFICHAGE DES COLLECTIONS===================");
printf("___affichage_instruction___\n");
visualize_Inst_queue(collec_instruct);
printf("___fin_instruction___\n\n");
printf("___affichage symbole___\n");
visualize_symb_queue(collec_symb);
printf("___fin symbole___\n\n");
printf("___affichage bss___\n");
visualize_bss_elem_queue(collec_bss);
printf("___fin bss___\n\n");
printf("___affichage data___\n");
visualize_data_elem_queue(collec_data);
printf("___fin data___\n\n");


printf("fin du code\n");

 return EXIT_SUCCESS;
}
