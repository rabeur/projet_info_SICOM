#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>

#include <global.h>
#include <notify.h>
#include <lex.h>

#include <LEXEM.h>
#include <TEST_FUNCTIONS.h>
#include <LIST.h>
#include <STRUCT.h>
#include <COLLECT.h>
#include <Dico.h>
#include <QUEUE.h>
/*Crée une file vide */
/*QUEUE create_queue(void){
  QUEUE q;
  q-
  return q;
}*/
/* ajoute un élément en fin de file*/
QUEUE create_QUEUE(void){
  QUEUE q;
  q.first = NULL;
  return q;
}

void queue_pull_on(QUEUE *q, void* pdata)
  {
    MAILLON *queue=calloc(1,sizeof(*queue));
        if (q == NULL || queue == NULL)
        {
          printf("error queue_pull_on\n");
            exit(EXIT_FAILURE);
        }
    queue->pdata=pdata;
    queue->next = NULL;
  /*  printf("step 0.1 ");*/
    if (q->first != NULL) /* La file n'est pas vide */
      {
          /* On se positionne à la fin de la file */
          MAILLON *elementActuel = q->first;
          /*printf("step 0.2 ");*/
          while (elementActuel->next != NULL)
          {
              elementActuel = elementActuel->next;
          }
          elementActuel->next = queue;
        /*  printf("step 0.3\n");*/
      }
      else /* La file est vide, notre élément est le premier */
      {
          q->first = queue;
          /*printf("step 0.0.2\n");*/
      }
  }

/* permet de visualiser la file */
void visualize_int_queue(QUEUE *q){
  if (q==NULL)
    printf("[]\n");
  else{
    printf("[");
    while((((MAILLON*)q->first)->next) != NULL)
    {
      void* Data = defiler (q);
      printf("content : %s, ligne : %i, type %d\n", ((LEXEM*)Data )-> content ,((LEXEM*)Data) -> lign, ((LEXEM*)Data) -> type);
    }
    printf("]\n");
    /*QUEUE queue=q->next;
    for(;queue!=q;queue=queue->next){
      if(queue==NULL){
        puts("Error: input isn't a queue.]");
        return;
      }
      printf("%d",*((int*)queue->pdata));
      if (queue!=q)
        printf(", ");
      }
    printf("%d]",*((int*)queue->pdata));*/
  }
}

/*Permet à la fct visualize_lexem_queue d'affichier le nom des enum dans la console*/
char tab_enum[16][20]={"COMMENT","NL","SYMBOLE","DIRECTIVE","VAL_DECIMAL","REGISTRE","COMA","STRING","VAL_HEXA","ERROR","FT","GUIL","PARENTO","PARENTC","DOT","EMPTY"};
void visualize_lexem_queue(QUEUE q){
  int i=1;
  while (q.first != NULL)
 {
   MAILLON *elementDefile = q.first;
   type_lexem(((LEXEM*)(elementDefile->pdata)));
   /*printf("step 4\n");*/
   void* Data = defiler (&q);
   /*printf("step 5\n");*/
   printf("Lexem %d: [content : %s | type: %s | lign %i]\n",i, ((LEXEM*)Data )-> content , tab_enum[((LEXEM*)Data) -> type], ((LEXEM*)Data) -> lign);
   q.first= elementDefile->next;
   i++;
 }
}

void visualize_Inst_queue(QUEUE q){
  int i=1;
  int k =1;
  /*printf("step 2\n");*/
  while (q.first != NULL)
 {
   printf("\n\n");
   MAILLON *elementDefile = q.first;
   /*type_lexem(((LEXEM*)(elementDefile->pdata)));*/
   /*printf("step 3\n");*/

   instruction* Data = defiler (&q);
   /*intruction Data =*/
   /*printf("step 6\n");*/
   printf("instruction %d: [nom = %s | type = %c | nb_op = %d | lign = %i | shift = %d ]\n",i, Data -> nom , Data -> inst_type,Data -> nb_op, Data-> lign,Data -> shift);
   /*printf("step 7\n");*/
   DATA_OP_INST* D1=((instruction*)Data )->Op1;
   OPTYPE_INST T=D1->type;
   if(T==4){
      k=4;
      /*printf("Instruction sans opérande\n");*/
  }
  /*printf("k = %d",k);*/
   while (k<4){
     /*printf("step 8\n");*/
     switch(k){
       case 1:
       ;
       if (Data -> nb_op==0) break;
       /*instruction* p_inst=((instruction*)Data );*/

       QUEUE* q0=D1->VAL_INST;
       printf("Op1 : ");
       printf("type =%d ||",D1->type);
       visualize_lexem_queue(*q0);

       /*printf("step 8.1.0\n");*/
       /*visualize_Inst_Op_queue(q0);*/

       break;

       case 2:
       ;
       if(Data -> nb_op==0 || Data -> nb_op==1) break;
       DATA_OP_INST* D2=((instruction*)Data )->Op2;
       QUEUE* q00=D2->VAL_INST;
       printf("Op2 : ");
       printf("type =%d ||",D2->type);
       visualize_lexem_queue(*q00);
       /*visualize_Inst_Op_queue(q00);*/
       break;

       case 3:
       ;
       if(Data -> nb_op==0 || Data -> nb_op==1 || Data ->nb_op== 2) break;
       DATA_OP_INST* D3=((instruction*)Data )->Op3;
       QUEUE* q000=D3->VAL_INST;
       printf("Op3 : ");
       printf("type =%d ||",D3->type);
       visualize_lexem_queue(*q000);
       /*visualize_Inst_Op_queue(q000);*/
       break;

       default:
       /*printf("too much operande for this instruction\n");*/
       break;
     }
     k++;
   }
    k=1;
    q.first= elementDefile->next;
   i++;
 }
}

void visualize_symb_queue(QUEUE q){
  int i=1;

  while (q.first != NULL)
 { MAILLON *elementDefile = q.first;
   SYMB* psymb = ((SYMB*)defiler (&q));
   printf("Symbole %d: [content = %s | lign = %d | shift = %d ]\n",i, psymb->content, psymb->lign,psymb->shift);
  q.first= elementDefile->next;
   i++;
 }
}

void visualize_bss_elem_queue(QUEUE q){
  int i=1;

  while (q.first != NULL)
 {
   MAILLON *elementDefile = q.first;
   BSS_ELEM* pbss = ((BSS_ELEM*)defiler (&q));
   printf("Bss element %d: [content = .space | operande= %s | lign = %d | shift = %d ]\n",i, pbss->op, pbss->lign,pbss->shift);
  q.first= elementDefile->next;
   i++;
 }
}

void visualize_data_elem_queue(QUEUE q){
  int i=1;
  char t_optype[4][10]={"BYTE","WORD","ASCIIZ","SPACE"};

  while (q.first != NULL)
 { MAILLON *elementDefile = q.first;
   DATA* pdata = ((DATA*)defiler (&q));
   OPTYPE type= pdata->op.type;

   printf("Data element %d: [Type = %s |",i, t_optype[type]);
  if(type==BYTE){
        printf("Operande = %c |", pdata->op.VAL.byte);}
  if(type==WORD){
        if(pdata->op.VAL.word.wtype==INT){
              printf("Operande = %d |", pdata->op.VAL.word.WORD.word_nb);}
        if(pdata->op.VAL.word.wtype==LABEL){
              printf("Operande = %s |", pdata->op.VAL.word.WORD.word_label);}
      }
  if(type==ASCIIZ){
        printf("Operande = %s |", pdata->op.VAL.asciiz);}
  if(type==SPACE){
        printf("Operande = %s |", pdata->op.VAL.space);}

   printf("élément %d | lign = %d | shift = %d ]\n",i, pdata->lign,pdata->shift);
  q.first= elementDefile->next;
   i++;
 }
}

void* defiler(QUEUE *q)
  {
      /*printf("step 4\n");*/
      if (q == NULL)
      {printf("Q est NULL"); exit(EXIT_FAILURE);}
      void* Data;
      /*printf("step 5\n");*/
      /* On vérifie s'il y a quelque chose à défiler */
      if (q->first != NULL)
      {
          /*printf("défile.1");*/
          MAILLON *elementDefile = q->first;
          Data = elementDefile->pdata;
          q->first= elementDefile->next;
          free(elementDefile);
      }
      return Data;
  }

  void free_queue(QUEUE *q)
  {
    if (q == NULL)
    {
        exit(EXIT_FAILURE);
    }
    /* On vérifie s'il y a quelque chose à défiler */
    if (q->first != NULL)
    {
        MAILLON *elementDefile = q->first;
        q->first= elementDefile->next;
        free(elementDefile);
    }
  }
