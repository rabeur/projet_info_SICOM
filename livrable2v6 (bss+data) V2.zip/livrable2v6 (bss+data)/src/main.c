#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>

#include <global.h>
#include <notify.h>
#include <lex.h>

#include <LEXEM.h>
#include <QUEUE.h>
#include <TEST_FUNCTIONS.h>
#include <LIST.h>
#include <STRUCT.h>
#include <COLLECT.h>
#include <Dico.h>


/*int man()
{ int nb_lex;
/*  char* path=strdup("tests/m.s");*/
  /*QUEUE q=create_lexem_queue(path);
  visualize_lexem_queue(q);
  printf("\nIl y a %d lexems\n",nb_lex);
}*/



int main(int argc, char* argv[])
{  /*Creation de la file de lexem à partir d'un fichier*/
  /*char* path=strdup("tests/m.s");*/
  int i;/*permetra de connaitre le numero du lexem*/
  int n=0;
  int nb_lex=0;
  int a=1;
/*---------------------------------------------------*/
  char* path=strdup(argv[1]);
  QUEUE q=create_lexem_queue(path);
  /*visualize_lexem_queue(q);*/
  int NbDefInstructions = 0; int k=0;
  inst_def_t* tab = lect_dico_int("tests/DICO_INSTRUCTION.txt",&NbDefInstructions);
  QUEUE collec_instruct=create_QUEUE();QUEUE collec_data=create_QUEUE();
  QUEUE collec_bss=create_QUEUE();QUEUE collec_symb=create_QUEUE(); /*choisir liste ou table de symbol*/
  QUEUE table_symb=create_QUEUE();
  int shift_inst=0;  int shift_data=0;
  int test_bss; int test_data;
  MAILLON* p=(MAILLON*)(q.first); /*liste_lexem;*/

  for (;p->next!=NULL;p=p->next){
    LEXEM* p_lex=((LEXEM*)(p->pdata));
    /*printf("ligne : %d | num : %d | content: %s \n",p_lex->lign,p_lex->num,p_lex->content);*/
    lextype type=p_lex->type;


    char t_type[16][20]={"COMMENT","NL","SYMBOLE","DIRECTIVE","VAL_DECIMAL","REGISTRE","COMA","STRING","VAL_HEXA","ERROR","FT","GUIL","PARENTO","PARENTC","DOT","EMPTY"};
    printf("lextype: %s || content: %s\n", t_type[type],p_lex->content);

    switch(type) { /*copier le switch apres le for pour le dernier lexem de la liste*/
        case DIRECTIVE :
        /*___________BSS PART__________*/

              if(strcmp(p_lex->content,".bss")==0){
                test_bss =collection_bss( p,&collec_bss, &collec_symb);
                if (test_bss == 0)
                {
                  printf("ERROR .BSS élément ligne %d : mal rentrée",((LEXEM*)p->pdata)->lign);
                  return EXIT_FAILURE;
                }
              }
              /*___________DATA PART__________*/
              else if(strcmp(p_lex->content,".data")==0){
                  test_data =collection_data( p,&collec_data, &collec_symb);
                  if (test_data == 0)
                  {
                    printf("ERROR .DATA élément ligne %d : mal rentrée",((LEXEM*)p->pdata)->lign);
                    return EXIT_FAILURE;
                  }
              }
           break;

        /*case STRING :
            i=0;
            if (recherche_instruction(p_lex->content,tab,NbDefInstructions,&i) == 1){
                  instruction* p_inst =  add_inst( p_lex->content, i-1, p_lex->lign, &shift_inst, tab);
                  queue_pull_on(&collec_instruct, p_inst);
            }
            else{
                  if(p->next==NULL){break;}
                  if(strcmp(((LEXEM*)(p->next->pdata))->content,":")==0){
                        add_symb(&collec_symb, p_lex->content, p_lex->lign);
                  }
           }*/

        /*case VAL_HEXA :
            printf("C'est une val hexa\n" );
            break;
        case ERROR :
            printf("C'est une erreur\n" );
            break;
        case FT :
           printf("C'est un, Fin de Texte\n" );
           break;
        case GUIL :
           printf("C'est une guillemet\n" );
           break;
        case PARENTO :
           printf("C'est une parenthese ouvrante\n" );
          break;
        case PARENTC :
           printf("C'est une parenthese fermante\n" );
          break;
        case DOT :
           printf("C'est un point\n" );
          break;
        case EMPTY :
           printf("C'est vide\n" );
          break;*/
        default :
           /*printf("C'est pas dans l'enum lextype\n" );
           /*collec_symb=add_symb(collec_symb, p_lex->content, p_lex->lign,2);/*faut creer une fct qui determine le dacallage du lexem! (a la place du 2)*/
           break;
  }
k++;
  }
/*visualize_lexem_queue(q);*/
/*visualize_Inst_queue(collec_instruct);*/
printf("___affichage symbole___\n");
visualize_symb_queue(collec_symb);
printf("___fin symbole___\n\n");
printf("___affichage bss___\n");
visualize_bss_elem_queue(collec_bss);
printf("___fin bss___\n\n");
printf("___affichage data___\n");
visualize_data_elem_queue(collec_data);
printf("___fin data___\n\n");

printf("end\n");
/*free_queue(q);*/
/*
  visualize_lexem_queue(q);
*/
 return EXIT_SUCCESS;
}
