#ifndef _TEST_TYPE
#define _TEST_TYPE
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>

#include <global.h>
#include <notify.h>
#include <lex.h>
#include <LIST.h>

int is_dot_space_n(MAILLON* p_l_lex, QUEUE* collec_bss, QUEUE* collec_symb);
int is_dot_primData_op(MAILLON* p_l_lex,QUEUE* collec_data, QUEUE* collec_symb);
int coma_then_op_byte(MAILLON* p,QUEUE* collec_data);
int coma_then_op_word(MAILLON* p,QUEUE* collec_data);
int coma_then_op_asciiz(MAILLON* p,QUEUE* collec_data);
int coma_then_op_space(MAILLON* p,QUEUE* collec_data);
int coma_then_n(MAILLON* p,QUEUE* collec_bss);
#endif
