#include<stdio.h>
#include<stdlib.h>
#include <string.h>
#include <ctype.h>
#include <strings.h>
#include <LEXEM.h>
#include <QUEUE.h>
#include <TEST_FUNCTIONS.h>
#include <LIST.h>

#include <global.h>
#include <notify.h>
#include <lex.h>
int is_in(char  c,char* tab,int n){  /*test si le caractere c appartient au tableau tab*/
  /*printf("is_in etape1\n");*/
  int i;
  if (n==0) {
    /*printf("is_in error\n");*/
    return 0;}
  for (i=0;i<n;i++){
    if (tab[i]==c) return 1;
    /*printf("is_in etape b%d\t",i);*/
    }
  return 0;
}
void test_commentaire(LEXEM* plex)
  {
    plex->type=COMMENT;
  }
void test_coma(LEXEM*plex){plex->type=COMA;}
void test_parentc(LEXEM*plex){plex->type=PARENTC;}
void test_parento(LEXEM*plex){plex->type=PARENTO;}
void test_mots(LEXEM*plex){plex->type=STRING;}
void test_NL(LEXEM*plex){plex->type=NL;}
void test_FT(LEXEM*plex){plex->type=FT;}
void test_guil(LEXEM*plex){plex->type=GUIL;}
void test_dot(LEXEM* plex){plex->type=DIRECTIVE;}
void test_registre(LEXEM* plex){

  char   regAvail[64][512]={"$0","$1","$2","$3","$4","$5","$6","$7","$8","$9","$10","$11","$12","$13","$14","$15","$16","$17","$18","$19","$20","$21",
  "$22","$23","$24","$25","$26","$27","$28","$29","$30","$31","$zero","$at","$v0","$v1","$a0","$a1","$a2","$a3","$t0","$t1","$t2","$t3","$t4","$t5","$t6",
  "$t7","$s0","$s1","$s2","$s3","$s4","$s5","$s6","$s7","$t8","$t9","$k0","$k1","$gp","$sp","$fp","$ra"};

  int i=0;
  char* s=plex->content;

  for (;i<64;i++)
  {
    if (strcasecmp(regAvail[i],s)==0)
      {plex->type=5;
        return ;}
  }
  plex->type=9;
  return;
}
void test_nombre(LEXEM* plex){
  char digit[10]={'0','1','2','3','4','5','6','7','8','9'};
  char digithexa[22]={'0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f','A','B','C','D','E','F'};

  char* pc=plex->content;
  int testdeci=1;
  int testhexa=1;

  /* Si le s commence par 0x on verifie que ce qui suit est bien un nombre hexa*/
  if (*pc=='0' && (*(pc+1)=='x' ||*(pc+1)=='X')){
    /*printf("hexa1 \n  ");*/
      pc+=2;
      do{
        testhexa=testhexa && is_in(*pc,digithexa,16);
        pc++;
      /*  printf("hexa2 : %d\n  ",testhexa);*/
      } while (*pc!='\0');
      /*printf("hexa2 : %d\n  ",testhexa);*/
      if (testhexa==1){
        plex->type=8;
      }
      else {
        char dest[512]="Hexadecimal doesn't exist - Lign ";
        /*strcat(dest,(char)plex->lign); */ /*pb sur cette fct*/
        strcpy(plex->error, dest);
        plex->type=9;
      }
  }

  /* On verifie que ce qui suit est bien un nombre decimal*/
  else if (*pc=='-' || *pc=='+'){
      pc++;
      while(*pc==' ') pc++; /*on passe les blancs entre les signes et les chiffres*/
      do{
        testdeci=testdeci && is_in(*pc,digit,10);
        pc++;
      }while (*pc!='\0');
      if (testdeci==1)
        plex->type=4;
      else {
        char dest[512]="Number doesn't exist - Lign ";
        /*strcat(dest,(char)plex->lign);*/ /*pb sur cette fct*/
        strcpy(plex->error, dest);
        plex->type=9;
      }
  }
  else {
    while(*pc==' ') pc++; /*on passe les blancs entre les signes et les chiffres*/
    do{
      testdeci=testdeci && is_in(*pc,digit,10);
      pc++;
    }while (*pc!='\0');
    if (testdeci==1)
      plex->type=4;
    else {
      char dest[512]="Number doesn't exist - Lign ";
      /*strcat(dest,(char)plex->lign);*/ /*pb sur cette fct*/
      strcpy(plex->error, dest);
      plex->type=9;
    }
  }
}

/*
LIST fill_list_number(int min, int max){
  if (min>max) return NULL;
  LIST l=create_list();
  char* tab =calloc(max-min+1,sizeof(*tab));
  int i;
  for (i=max;i>=min;i--){
    tab[i-1]=(char)i;
    printf("%c, ", tab[i-1]);
    l=head_insert_list(l,tab+i-1);
    }
}
*/
