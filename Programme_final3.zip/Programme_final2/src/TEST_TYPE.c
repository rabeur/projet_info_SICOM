#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>

#include <global.h>
#include <notify.h>
#include <lex.h>
#include <COLLECT.h>
#include <LEXEM.h>
#include <QUEUE.h>
#include <TEST_FUNCTIONS.h>
#include <LIST.h>
#include <STRUCT.h>

#include <Dico.h>
#include <TEST_TYPE.h>

/*Verifie si à partir du lexem actuel on a un .space n ou .space n1,...,nn correct,
si oui renvoie 1 et modifie le pointeur de liste
sinon renvoie 0 sans modifier le pointeur*/
int coma_then_n(MAILLON*  p,QUEUE* collec_bss){  /*(QUEUE* p_q, char* op, int lign)*/
  if((((LEXEM*)(p->pdata))->type)==COMA){
    LEXEM* p_lex=((LEXEM*)(p->next->pdata));
    if((p_lex->type)==VAL_DECIMAL){
      add_bss_elem(collec_bss, p_lex->content, p_lex->lign);
      return 1;
    }
    ERROR_MSG("Erreur: argument invalide pour .space (vigule en trop ou manque une valeur décimale)- ligne %d",p_lex->lign);
  }
    return 0;
}

int is_dot_space_n(MAILLON* p_l_lex,QUEUE* collec_bss, QUEUE* collec_symb){
  int test_bss;
  MAILLON* p=p_l_lex;
  LEXEM* p_lex=((LEXEM*)(p->pdata));

  if(strcmp(p_lex->content,".space")==0){

      p=p->next;
      p_lex=((LEXEM*)(p->pdata));
      if(p_lex->type==VAL_DECIMAL){
          add_bss_elem(collec_bss, p_lex->content, p_lex->lign);
          p=p->next;
          p_lex=((LEXEM*)(p->pdata));

          while(coma_then_n(p,collec_bss) == 1){
              p=p->next->next;
              p_lex=((LEXEM*)(p->pdata));
          }
          p_l_lex=p;
          return test_bss=1;
      }
      else{
        ERROR_MSG("Erreur: argument invalide pour .space (l'opérande n'est une une valeur décimale)- ligne %d",p_lex->lign);
        return test_bss = 0;
      }
  }
  else{
    return test_bss = 0;
  }/*si ca commence pas par .space c'est pas forcement une erreur */
}

  /*
  create_DATA_OP_byte(char byte);
  create_DATA_OP_word(int word);
  DATA_OP* create_DATA_OP_asciiz(char* asciiz);
  DATA_OP* create_DATA_OP_space(unsigned int space);
  */

int is_dot_primData_op(MAILLON* p_l_lex, QUEUE* collec_data, QUEUE* collec_symb){

  MAILLON* p=p_l_lex;
  LEXEM* p_lex=((LEXEM*)(p->pdata));

  if(strcmp(p_lex->content,".byte")==0){

      p=p->next;
      p_lex=((LEXEM*)(p->pdata));
      if(p_lex->type==VAL_DECIMAL){
          DATA_OP* p_op=create_DATA_OP_byte((char)((p_lex->content)[0]));
          add_data_elem(collec_data, *p_op, p_lex->lign);
          p=p->next;
          p_lex=((LEXEM*)(p->pdata));

          while(coma_then_op_byte(p,collec_data)){
              p=p->next->next;
              p_lex=((LEXEM*)(p->pdata));
          }
          p_l_lex=p;
          return 1;
      }
      else{
        ERROR_MSG("Erreur: argument invalide pour .byte (l'opérande n'est pas une valeur)- ligne %d",p_lex->lign);
        return 0;
      }
  }

  else if(strcmp(p_lex->content,".word")==0){

      p=p->next;
      p_lex=((LEXEM*)(p->pdata));
      if(p_lex->type==VAL_DECIMAL || p_lex->type==VAL_HEXA || p_lex->type==STRING){/* ou etiquette string*/
            if(p_lex->type==VAL_DECIMAL || p_lex->type==VAL_HEXA){
                  DATA_OP* p_op=create_DATA_OP_word_nb((int)strtol(p_lex->content,NULL,0));
                  add_data_elem(collec_data, *p_op, p_lex->lign);
                  p=p->next;
                  p_lex=((LEXEM*)(p->pdata));
            }
            if(p_lex->type==STRING){
                  DATA_OP* p_op=create_DATA_OP_word_label(p_lex->content);
                  add_data_elem(collec_data, *p_op, p_lex->lign);
                  p=p->next;
                  p_lex=((LEXEM*)(p->pdata));
            }
          while(coma_then_op_word(p,collec_data)){
              p=p->next->next;
              p_lex=((LEXEM*)(p->pdata));
          }
          p_l_lex=p;
          return 1;
      }
      else{
        ERROR_MSG("Erreur: argument invalide pour .word (l'opérande n'est pas une valeur)- ligne %d",p_lex->lign);
        return 0;
      }
  }

  else if(strcmp(p_lex->content,".asciiz")==0){
      char tmp[512];
      p=p->next;
      p_lex=((LEXEM*)(p->pdata));

      if(p_lex->type==GUIL){
            p=p->next;
            p_lex=((LEXEM*)(p->pdata));
            if(p_lex->type==STRING){
                  strcpy(tmp,p_lex->content);
                  p=p->next;
                  p_lex=((LEXEM*)(p->pdata));
                  while(p_lex->type==STRING){
                        strcat(tmp,p_lex->content);
                        p=p->next;
                        p_lex=((LEXEM*)(p->pdata));
                        }
                  if(p_lex->type==GUIL){
                        DATA_OP* p_op=create_DATA_OP_asciiz(tmp);
                        add_data_elem(collec_data, *p_op, p_lex->lign);
                        return 1;
                  }
                  else{
                        ERROR_MSG("Erreur: argument invalide pour .asciiz (l'opérande n'est pas une chaine de caractères valides)- ligne %d",p_lex->lign);
                        return 0;
                  }
            }
            else{
                  ERROR_MSG("Erreur: argument invalide pour .asciiz (l'opérande n'est pas une chaine de caractères valides)- ligne %d",p_lex->lign);
                  return 0;
            }
      }
      else{
            ERROR_MSG("Erreur: argument invalide pour .asciiz (l'opérande n'est pas une chaine de caractères valides)- ligne %d",p_lex->lign);
            return 0;
      }
  }

  else if(strcmp(p_lex->content,".space")==0){

      p=p->next;
      p_lex=((LEXEM*)(p->pdata));

      if(p_lex->type==VAL_DECIMAL || p_lex->type==VAL_HEXA){
            DATA_OP* p_op=create_DATA_OP_space((unsigned int)strtol(p_lex->content,NULL,0));
            add_data_elem(collec_data, *p_op, p_lex->lign);
            p=p->next;
            p_lex=((LEXEM*)(p->pdata));

          while(0 && coma_then_op_space(p,collec_data)){
              p=p->next->next;
              p_lex=((LEXEM*)(p->pdata));
          }
          p_l_lex=p;
          return 1;
      }
      else{
        ERROR_MSG("Erreur: argument invalide pour .space (l'opérande n'est pas une valeur décimale)- ligne %d",p_lex->lign);
        return 0;
      }
  }

  else{
    return 0;
  }/*si ca commence pas par .space c'est pas forcement une erreur */
}

int coma_then_op_byte(MAILLON* p,QUEUE* collec_data){  /*(QUEUE* p_q, char* op, int lign)*/
  if((((LEXEM*)(p->pdata))->type)==COMA){
    LEXEM* p_lex=((LEXEM*)(p->next->pdata));
    if((p_lex->type)==VAL_DECIMAL){
      DATA_OP* p_op=create_DATA_OP_byte((char)((p_lex->content)[0]));
      add_data_elem(collec_data, *p_op, p_lex->lign);
      return 1;
    }
    ERROR_MSG("Erreur: argument invalide pour .byte (vigule en trop ou manque une valeur)- ligne %d",p_lex->lign);
    return 0;
  }
    return 0;
}

int coma_then_op_word(MAILLON* p,QUEUE* collec_data){  /*(QUEUE* p_q, char* op, int lign)*/
  if((((LEXEM*)(p->pdata))->type)==COMA){
    LEXEM* p_lex=((LEXEM*)(p->next->pdata));
    if((p_lex->type)==VAL_DECIMAL || p_lex->type==VAL_HEXA || p_lex->type==STRING){

      if(p_lex->type==VAL_DECIMAL || p_lex->type==VAL_HEXA){
            DATA_OP* p_op=create_DATA_OP_word_nb((int)strtol(p_lex->content,NULL,0));
            add_data_elem(collec_data, *p_op, p_lex->lign);
            return 1;
      }
      if(p_lex->type==STRING){
            DATA_OP* p_op=create_DATA_OP_word_label(p_lex->content);
            add_data_elem(collec_data, *p_op, p_lex->lign);
            return 1;
      }
    }
    ERROR_MSG("Erreur: argument invalide pour .word (virgule en trop ou manque une valeur)- ligne %d",p_lex->lign);
    return 0;
  }
    return 0;
}

int coma_then_op_asciiz(MAILLON* p,QUEUE* collec_data){  /*(QUEUE* p_q, char* op, int lign)*/
  if((((LEXEM*)(p->pdata))->type)==COMA){
    LEXEM* p_lex=((LEXEM*)(p->next->pdata));
    if((p_lex->type)==STRING){
      DATA_OP* p_op=create_DATA_OP_asciiz(p_lex->content);
      add_data_elem(collec_data, *p_op, p_lex->lign);
      return 1;
    }
    ERROR_MSG("Erreur: argument invalide pour .asciiz (vigule en trop ou manque une valeur)- ligne %d",p_lex->lign);
    return 0;
  }
    return 0;
}

int coma_then_op_space(MAILLON* p,QUEUE* collec_data){  /*(QUEUE* p_q, char* op, int lign)*/
  if((((LEXEM*)(p->pdata))->type)==COMA){
    LEXEM* p_lex=((LEXEM*)(p->next->pdata));
    if((p_lex->type)==VAL_DECIMAL || (p_lex->type)==VAL_HEXA){
      /*DATA_OP* p_op=create_DATA_OP_space((unsigned int)strtol(p_lex->content,NULL,0));*/
      add_bss_elem(collec_data, p_lex->content, p_lex->lign);
      return 1;
    }
    ERROR_MSG("Erreur: argument invalide pour .space (virgule en trop ou manque une valeur décimale)- ligne %d",p_lex->lign);
    return 0;
  }
    return 0;
}
