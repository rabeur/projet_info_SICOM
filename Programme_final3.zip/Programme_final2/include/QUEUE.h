#ifndef _QUEUE
#define _QUEUE
#include <LIST.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>

#include <global.h>
#include <notify.h>






typedef struct QUEUE QUEUE;
struct QUEUE
{
  MAILLON *first;
};

QUEUE create_QUEUE(void);
void queue_pull_on(QUEUE*, void*);
void visualize_int_queue(QUEUE* q);
void visualize_lexem_queue(QUEUE q);
void visualize_Inst_queue(QUEUE  q);
void visualize_symb_queue(QUEUE q);
void visualize_bss_elem_queue(QUEUE q);
void visualize_data_elem_queue(QUEUE q);
void* defiler(QUEUE* q);
void free_queue(QUEUE *q);
void visualize_collections(QUEUE collec_instruct,QUEUE collec_symb,QUEUE collec_bss,QUEUE collec_data);


#endif
