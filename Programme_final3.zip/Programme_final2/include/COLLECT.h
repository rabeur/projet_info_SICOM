#ifndef _COLLECT
#define _COLLECT

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>

#include <global.h>
#include <notify.h>
#include <lex.h>

#include <LEXEM.h>
#include <QUEUE.h>
#include <TEST_FUNCTIONS.h>
#include <LIST.h>
#include <STRUCT.h>
#include <Dico.h>

/*            INSTRUCTION                                */
int collection_instruction(MAILLON* p, QUEUE* collec_instruct, QUEUE* collec_symb, int* shift_txt, inst_def_t* tab, int NbDefInstructions);
instruction* add_inst(char * content,int i , int lign,int* shift_inst, inst_def_t* tab);
int recherche_instruction(char* content,inst_def_t* tab,int NbDefInstructions, int* i);
int modif_Op_inst(instruction* p_inst,MAILLON* p );
int recherche_Op_c1(MAILLON* p,instruction* p_inst);
int recherche_Op_c2(MAILLON* p,instruction* p_inst);
int recherche_Op_c3(MAILLON* p,instruction* p_inst);
int def_type_Op(DATA_OP_INST* Op);
int test_inst(instruction* p_inst, inst_def_t* tab);
int extract_Op(instruction* p_inst);
int extract_reg(DATA_OP_INST* Op);
int extract_reg_sp(char* s,DATA_OP_INST* Op,int val );


/*                  BSS              */
void add_bss_elem(QUEUE* collec_bss, char* op, int lign);
int collection_bss(MAILLON* p, QUEUE* collec_bss, QUEUE* collec_symb);


/*                      DATA                     */
int collection_data(MAILLON* p,QUEUE* collec_bss, QUEUE* collec_symb);
DATA_OP* create_DATA_OP_byte(char byte);
DATA_OP* create_DATA_OP_word_nb(int word);
DATA_OP* create_DATA_OP_word_label(char* word);
DATA_OP* create_DATA_OP_asciiz(char* asciiz);
DATA_OP* create_DATA_OP_space(unsigned int space);
void add_data_elem(QUEUE* collec_data, DATA_OP op, int lign);

/*           SYMBOLE              */
void add_symb(QUEUE* collec_symb, char* content, int lign);
int test_etiquette(MAILLON* p,  QUEUE* collec_symb);


#endif
