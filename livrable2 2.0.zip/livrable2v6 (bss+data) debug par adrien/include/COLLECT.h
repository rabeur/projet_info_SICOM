#ifndef _COLLECT
#define _COLLECT

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>

#include <global.h>
#include <notify.h>
#include <lex.h>

#include <LEXEM.h>
#include <QUEUE.h>
#include <TEST_FUNCTIONS.h>
#include <LIST.h>
#include <STRUCT.h>
#include <Dico.h>

instruction* add_inst(char * content,int i , int lign,int* shift_inst, inst_def_t* tab);
void add_symb(QUEUE* collec_symb, char* content, int lign);
void add_bss_elem(QUEUE* collec_bss, char* op, int lign);

void add_data_elem(QUEUE* collec_data, DATA_OP op, int lign);


int recherche_instruction(char* content,inst_def_t* tab,int NbDefInstructions, int* i);
void modif_Op_inst(instruction* p_inst);

DATA_OP* create_DATA_OP_byte(char byte);
DATA_OP* create_DATA_OP_word_nb(int word);
DATA_OP* create_DATA_OP_word_label(char* word);
DATA_OP* create_DATA_OP_asciiz(char* asciiz);
DATA_OP* create_DATA_OP_space(unsigned int space);

int collection_data(MAILLON* p,QUEUE* collec_bss, QUEUE* collec_symb);

int collection_bss(MAILLON* p, QUEUE* collec_bss, QUEUE* collec_symb);

int test_etiquette(MAILLON* p,  QUEUE* collec_symb);
#endif
